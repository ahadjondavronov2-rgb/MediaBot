import os
import uuid
import asyncio
from concurrent.futures import ThreadPoolExecutor

import yt_dlp

from config import DOWNLOADS_DIR, MAX_FILE_SIZE_MB

os.makedirs(DOWNLOADS_DIR, exist_ok=True)
_executor = ThreadPoolExecutor(max_workers=3)

# YouTube Shorts va barcha formatlar uchun universal format
FORMATS = {
    "360": "worst[ext=mp4]/worst",
    "720": (
        "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/"
        "bestvideo[height<=720]+bestaudio/"
        "best[height<=720][ext=mp4]/"
        "best[height<=720]/best"
    ),
    "1080": (
        "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/"
        "bestvideo[height<=1080]+bestaudio/"
        "best[height<=1080][ext=mp4]/"
        "best[height<=1080]/best"
    ),
    "4k": (
        "bestvideo[height<=2160][ext=mp4]+bestaudio[ext=m4a]/"
        "bestvideo[height<=2160]+bestaudio/"
        "best[height<=2160]/best"
    ),
}


def _build_opts(quality: str, output_template: str) -> dict:
    return {
        "format": FORMATS.get(quality, FORMATS["720"]),
        "outtmpl": output_template,
        "merge_output_format": "mp4",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "extractor_retries": 3,
        "postprocessors": [
            {"key": "FFmpegVideoConvertor", "preferedformat": "mp4"}
        ],
    }


def _run_download(url: str, opts: dict):
    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([url])


def _run_info(url: str) -> dict | None:
    with yt_dlp.YoutubeDL({
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
    }) as ydl:
        return ydl.extract_info(url, download=False)


async def download_video(url: str, quality: str = "720") -> str | None:
    file_id = uuid.uuid4().hex[:12]
    output_template = os.path.join(DOWNLOADS_DIR, f"{file_id}.%(ext)s")
    opts = _build_opts(quality, output_template)
    loop = asyncio.get_event_loop()
    try:
        await loop.run_in_executor(_executor, _run_download, url, opts)
    except Exception as e:
        print(f"[downloader] error (quality={quality}): {e}")
        return None

    for fname in os.listdir(DOWNLOADS_DIR):
        if fname.startswith(file_id):
            fpath = os.path.join(DOWNLOADS_DIR, fname)
            try:
                size_mb = os.path.getsize(fpath) / (1024 * 1024)
            except OSError:
                return None
            if size_mb > MAX_FILE_SIZE_MB:
                os.remove(fpath)
                return "TOO_LARGE"
            return fpath
    return None


async def get_video_info(url: str) -> dict | None:
    loop = asyncio.get_event_loop()
    try:
        return await loop.run_in_executor(_executor, _run_info, url)
    except Exception as e:
        print(f"[downloader] info error: {e}")
        return None


def cleanup(filepath: str | None):
    if not filepath or filepath == "TOO_LARGE":
        return
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
    except Exception:
        pass
