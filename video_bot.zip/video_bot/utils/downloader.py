import os
import re
import uuid
import asyncio
import tempfile
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import unquote

import yt_dlp

from config import DOWNLOADS_DIR, MAX_FILE_SIZE_MB, IG_SESSION_ID, YT_COOKIES

os.makedirs(DOWNLOADS_DIR, exist_ok=True)
_executor = ThreadPoolExecutor(max_workers=3)

# ── Cookie fayllarini yaratish ─────────────────────────────────────────────────

_IG_COOKIES_FILE: str | None = None
_YT_COOKIES_FILE: str | None = None


def _create_ig_cookies() -> str | None:
    """Instagram sessionid dan Netscape cookies.txt yaratish"""
    if not IG_SESSION_ID:
        print("[downloader] IG_SESSION_ID topilmadi")
        return None

    # URL decode qilish (masalan %3A → :)
    session_id = unquote(IG_SESSION_ID)

    # Netscape cookie format
    cookie_content = (
        "# Netscape HTTP Cookie File\n"
        ".instagram.com\tTRUE\t/\tTRUE\t2147483647\tsessionid\t{}\n"
        ".instagram.com\tTRUE\t/\tFALSE\t2147483647\tds_user_id\t{}\n"
    ).format(session_id, session_id.split("%3A")[0].split(":")[0])

    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".txt", delete=False, encoding="utf-8"
    )
    tmp.write(cookie_content)
    tmp.close()
    print(f"[downloader] Instagram cookies fayl yaratildi: {tmp.name}")
    return tmp.name


def _create_yt_cookies() -> str | None:
    """YouTube cookies dan fayl yaratish"""
    if not YT_COOKIES or not YT_COOKIES.strip():
        return None
    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".txt", delete=False, encoding="utf-8"
    )
    tmp.write(YT_COOKIES)
    tmp.close()
    print(f"[downloader] YouTube cookies fayl yaratildi: {tmp.name}")
    return tmp.name


_IG_COOKIES_FILE = _create_ig_cookies()
_YT_COOKIES_FILE = _create_yt_cookies()

# ── Format stringlar ───────────────────────────────────────────────────────────

FORMATS = {
    "360": "worst[ext=mp4]/worst",
    "720": (
        "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/"
        "bestvideo[height<=720]+bestaudio/"
        "best[height<=720][ext=mp4]/best[height<=720]/best"
    ),
    "1080": (
        "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/"
        "bestvideo[height<=1080]+bestaudio/"
        "best[height<=1080][ext=mp4]/best[height<=1080]/best"
    ),
    "4k": (
        "bestvideo[height<=2160][ext=mp4]+bestaudio[ext=m4a]/"
        "bestvideo[height<=2160]+bestaudio/"
        "best[height<=2160]/best"
    ),
}


def _clean_url(url: str) -> str:
    url = url.strip()
    url = re.sub(r'[?&]si=[^&]*', '', url)
    url = re.sub(r'[?&]pp=[^&]*', '', url)
    url = re.sub(r'[?&]feature=[^&]*', '', url)
    url = re.sub(r'[?&]$', '', url)
    return url


def _is_instagram(url: str) -> bool:
    return "instagram.com" in url or "instagr.am" in url


def _build_opts(url: str, quality: str, output_template: str) -> dict:
    """URL ga qarab to'g'ri cookies va sozlamalarni qo'llash"""
    opts = {
        "format": FORMATS.get(quality, FORMATS["720"]),
        "outtmpl": output_template,
        "merge_output_format": "mp4",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "extractor_retries": 3,
        "postprocessors": [
            {"key": "FFmpegVideoConvertor", "preferedformat": "mp4"}
        ],
    }

    if _is_instagram(url):
        # Instagram uchun sessionid cookie
        if _IG_COOKIES_FILE:
            opts["cookiefile"] = _IG_COOKIES_FILE
        opts["http_headers"] = {
            "User-Agent": (
                "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
                "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 "
                "Mobile/15E148 Safari/604.1"
            ),
        }
    else:
        # YouTube uchun cookies + iOS client
        if _YT_COOKIES_FILE:
            opts["cookiefile"] = _YT_COOKIES_FILE
        opts["extractor_args"] = {
            "youtube": {"player_client": ["ios", "web"]}
        }

    return opts


def _build_info_opts(url: str) -> dict:
    opts = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
    }
    if _is_instagram(url):
        if _IG_COOKIES_FILE:
            opts["cookiefile"] = _IG_COOKIES_FILE
        opts["http_headers"] = {
            "User-Agent": (
                "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
                "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 "
                "Mobile/15E148 Safari/604.1"
            ),
        }
    else:
        if _YT_COOKIES_FILE:
            opts["cookiefile"] = _YT_COOKIES_FILE
        opts["extractor_args"] = {
            "youtube": {"player_client": ["ios", "web"]}
        }
    return opts


def _run_download(url: str, opts: dict):
    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([url])


def _run_info(url: str, opts: dict) -> dict | None:
    with yt_dlp.YoutubeDL(opts) as ydl:
        return ydl.extract_info(url, download=False)


async def download_video(url: str, quality: str = "720") -> str | None:
    url = _clean_url(url)
    file_id = uuid.uuid4().hex[:12]
    output_template = os.path.join(DOWNLOADS_DIR, f"{file_id}.%(ext)s")
    opts = _build_opts(url, quality, output_template)
    loop = asyncio.get_event_loop()

    try:
        await loop.run_in_executor(_executor, _run_download, url, opts)
    except Exception as e:
        print(f"[downloader] download error: {e}")
        return None

    for fname in os.listdir(DOWNLOADS_DIR):
        if fname.startswith(file_id):
            fpath = os.path.join(DOWNLOADS_DIR, fname)
            try:
                size_mb = os.path.getsize(fpath) / (1024 * 1024)
            except OSError:
                return None
            if size_mb > MAX_FILE_SIZE_MB:
                os.remove(fpath)
                return "TOO_LARGE"
            return fpath
    return None


async def get_video_info(url: str) -> dict | None:
    url = _clean_url(url)
    opts = _build_info_opts(url)
    loop = asyncio.get_event_loop()
    try:
        return await loop.run_in_executor(_executor, _run_info, url, opts)
    except Exception as e:
        print(f"[downloader] info error: {e}")
        return None


def cleanup(filepath: str | None):
    if not filepath or filepath == "TOO_LARGE":
        return
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
    except Exception:
        pass
