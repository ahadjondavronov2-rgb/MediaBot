import os, re, uuid, asyncio, tempfile
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import unquote
import yt_dlp
from config import DOWNLOADS_DIR, MAX_FILE_SIZE_MB, IG_SESSION_ID, YT_COOKIES_FILE

os.makedirs(DOWNLOADS_DIR, exist_ok=True)
_executor = ThreadPoolExecutor(max_workers=3)

# ─── Chrome User-Agent (Windows) ─────────────────────────────────────────────
# YouTube cookies bilan ishlaganda brauzer bilan bir xil User-Agent bo'lishi
# shart — aks holda cookie "o'g'irlangan" deb bloklanishi mumkin.
_CHROME_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/125.0.0.0 Safari/537.36"
)

# ─── Invidious instancelari ───────────────────────────────────────────────────
# Biri ishlamasa avtomatik keyingisiga o'tadi.
# Yangi ishlaydigan instancelarni https://api.invidious.io/ dan topish mumkin.
_INVIDIOUS_INSTANCES = [
    "https://inv.tux.pizza",
    "https://invidious.privacyredirect.com",
    "https://yt.artemislena.eu",
    "https://invidious.nikkosphere.com",
    "https://iv.melmac.space",
]


# ═══════════════════════════════════════════════════════════════════════════════
#  ARXITEKTURA — 3 QATLAM HIMOYA
# ═══════════════════════════════════════════════════════════════════════════════
#
#  1-qatlam ─ YouTube Cookies
#     Render da /etc/secrets/yt_cookies.txt mavjud bo'lsa,
#     to'g'ridan YouTube serveridan yuklab oladi.
#     Eng tez, eng sifatli (4K, 1080p ishlaydi).
#     Muammo: cookie 2-4 haftada eskiradi, yangilash kerak.
#
#  2-qatlam ─ Invidious (fallback)
#     Cookies yo'q yoki ishlamasa, invidious:VIDEO_ID formatiga o'tadi.
#     YouTube serverlariga umuman murojaat qilinmaydi.
#     IP blok, 403, JS runtime xatolari bunday bo'lmaydi.
#
#  3-qatlam ─ Invidious multi-instance
#     music_finder.py da 5 ta instance — biri o'chsa keyingisi ishga tushadi.
#
#  Natija: bot HECH QACHON ishlamay qolmaydi ✅
# ═══════════════════════════════════════════════════════════════════════════════


# ─── YouTube URL → Video ID ───────────────────────────────────────────────────

_YT_ID_RE = re.compile(
    r'(?:youtube\.com/(?:watch\?(?:[^#]*&)?v=|shorts/|embed/|v/)'
    r'|youtu\.be/)'
    r'([A-Za-z0-9_-]{11})'
)

def _extract_yt_id(url: str) -> str | None:
    m = _YT_ID_RE.search(url)
    return m.group(1) if m else None

def _to_invidious(url: str) -> str:
    """YouTube URL → 'invidious:VIDEO_ID'"""
    vid_id = _extract_yt_id(url)
    if vid_id:
        print(f"[downloader] Invidious fallback: invidious:{vid_id}")
        return f"invidious:{vid_id}"
    return url

def _is_youtube_url(url: str) -> bool:
    return (
        ("youtube.com" in url or "youtu.be" in url)
        and not url.startswith("invidious:")
    )

def _is_instagram(url: str) -> bool:
    return "instagram.com" in url or "instagr.am" in url


# ─── Cookies fayl tekshiruvi ──────────────────────────────────────────────────

def _yt_cookies_ok() -> bool:
    """
    YouTube cookies fayli mavjud va bo'sh emasligini tekshiradi.
    Fayl yo'q yoki bo'sh bo'lsa — Invidious ishlatiladi.
    """
    if not YT_COOKIES_FILE:
        return False
    try:
        return os.path.isfile(YT_COOKIES_FILE) and os.path.getsize(YT_COOKIES_FILE) > 100
    except OSError:
        return False


# ─── Instagram cookie ─────────────────────────────────────────────────────────

def _create_ig_cookies() -> str | None:
    if not IG_SESSION_ID:
        return None
    sid = unquote(IG_SESSION_ID.strip())
    uid = sid.split(":")[0] if ":" in sid else sid.split("%3A")[0]
    content = (
        "# Netscape HTTP Cookie File\n"
        f".instagram.com\tTRUE\t/\tTRUE\t2147483647\tsessionid\t{sid}\n"
        f".instagram.com\tTRUE\t/\tFALSE\t2147483647\tds_user_id\t{uid}\n"
    )
    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".txt", delete=False, encoding="utf-8"
    )
    tmp.write(content)
    tmp.close()
    print("[downloader] Instagram cookies ✅")
    return tmp.name

_IG_COOKIES_FILE: str | None = _create_ig_cookies()


# ─── Format tanlash ───────────────────────────────────────────────────────────

FORMATS = {
    "360": "worst[ext=mp4]/worst",
    "720": (
        "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/"
        "bestvideo[height<=720]+bestaudio/"
        "best[height<=720][ext=mp4]/best[height<=720]/best"
    ),
    "1080": (
        "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/"
        "bestvideo[height<=1080]+bestaudio/"
        "best[height<=1080][ext=mp4]/best[height<=1080]/best"
    ),
    "4k": (
        "bestvideo[height<=2160][ext=mp4]+bestaudio[ext=m4a]/"
        "bestvideo[height<=2160]+bestaudio/best[height<=2160]/best"
    ),
}


# ─── yt-dlp sozlamalari ───────────────────────────────────────────────────────

def _clean_url(url: str) -> str:
    url = url.strip()
    for p in ['si', 'pp', 'feature']:
        url = re.sub(rf'[?&]{p}=[^&]*', '', url)
    return re.sub(r'[?&]$', '', url)


def _yt_cookie_dl_opts(quality: str, output: str) -> dict:
    """
    1-qatlam: YouTube cookies bilan to'g'ridan yuklab olish sozlamalari.
    cookiefile + Chrome User-Agent majburiy — cookie expired bo'lmasligi uchun.
    """
    return {
        "format": FORMATS.get(quality, FORMATS["720"]),
        "outtmpl": output,
        "merge_output_format": "mp4",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "extractor_retries": 2,
        "cookiefile": YT_COOKIES_FILE,
        "http_headers": {"User-Agent": _CHROME_UA},
        "postprocessors": [
            {"key": "FFmpegVideoConvertor", "preferedformat": "mp4"}
        ],
    }


def _yt_cookie_info_opts() -> dict:
    """1-qatlam: cookies bilan video ma'lumot olish."""
    return {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "cookiefile": YT_COOKIES_FILE,
        "http_headers": {"User-Agent": _CHROME_UA},
    }


def _invidious_dl_opts(quality: str, output: str) -> dict:
    """2-qatlam: Invidious format uchun sozlamalar."""
    return {
        "format": FORMATS.get(quality, FORMATS["720"]),
        "outtmpl": output,
        "merge_output_format": "mp4",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "extractor_retries": 3,
        "postprocessors": [
            {"key": "FFmpegVideoConvertor", "preferedformat": "mp4"}
        ],
    }


def _invidious_info_opts() -> dict:
    """2-qatlam: Invidious format uchun info sozlamalari."""
    return {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
    }


def _ig_dl_opts(quality: str, output: str) -> dict:
    """Instagram yuklab olish sozlamalari."""
    opts: dict = {
        "format": FORMATS.get(quality, FORMATS["720"]),
        "outtmpl": output,
        "merge_output_format": "mp4",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "extractor_retries": 3,
        "http_headers": {
            "User-Agent": (
                "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
                "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 "
                "Mobile/15E148 Safari/604.1"
            ),
        },
        "postprocessors": [
            {"key": "FFmpegVideoConvertor", "preferedformat": "mp4"}
        ],
    }
    if _IG_COOKIES_FILE:
        opts["cookiefile"] = _IG_COOKIES_FILE
    return opts


def _ig_info_opts() -> dict:
    opts: dict = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "http_headers": {
            "User-Agent": (
                "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
                "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 "
                "Mobile/15E148 Safari/604.1"
            ),
        },
    }
    if _IG_COOKIES_FILE:
        opts["cookiefile"] = _IG_COOKIES_FILE
    return opts


# ─── yt-dlp ishga tushirish ───────────────────────────────────────────────────

def _run_dl(url: str, opts: dict):
    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([url])

def _run_info(url: str, opts: dict) -> dict | None:
    with yt_dlp.YoutubeDL(opts) as ydl:
        return ydl.extract_info(url, download=False)


# ─── Ichki yordamchi: fayl topish ─────────────────────────────────────────────

def _find_file(fid: str) -> str | None:
    """fid bilan boshlanadigan yuklab olingan faylni topadi."""
    for fname in os.listdir(DOWNLOADS_DIR):
        if fname.startswith(fid):
            fpath = os.path.join(DOWNLOADS_DIR, fname)
            try:
                size_mb = os.path.getsize(fpath) / 1024 / 1024
            except OSError:
                return None
            if size_mb > MAX_FILE_SIZE_MB:
                os.remove(fpath)
                return "TOO_LARGE"
            return fpath
    return None


def _cleanup_partial(fid: str):
    """Muvaffaqiyatsiz urinishdan qolgan qisman fayllarni o'chiradi."""
    for fname in os.listdir(DOWNLOADS_DIR):
        if fname.startswith(fid):
            try:
                os.remove(os.path.join(DOWNLOADS_DIR, fname))
            except Exception:
                pass


async def _exec_dl(url: str, opts: dict, fid: str) -> str | None:
    """yt-dlp ni async ishga tushiradi. Xato bo'lsa None qaytaradi."""
    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(_executor, _run_dl, url, opts)
    except Exception as e:
        print(f"[downloader] xato: {e}")
        return None
    return _find_file(fid)


# ═══════════════════════════════════════════════════════════════════════════════
#  ASOSIY FUNKSIYALAR
# ═══════════════════════════════════════════════════════════════════════════════

async def download_video(url: str, quality: str = "720") -> str | None:
    url = _clean_url(url)

    # ── Instagram ──────────────────────────────────────────────────────────────
    if _is_instagram(url):
        fid = uuid.uuid4().hex[:12]
        out = os.path.join(DOWNLOADS_DIR, f"{fid}.%(ext)s")
        return await _exec_dl(url, _ig_dl_opts(quality, out), fid)

    # ── YouTube ────────────────────────────────────────────────────────────────
    if _is_youtube_url(url):

        # 1-qatlam: Cookies bilan to'g'ridan YouTube
        if _yt_cookies_ok():
            print("[downloader] 1-qatlam: Cookies bilan urinish...")
            fid1 = uuid.uuid4().hex[:12]
            out1 = os.path.join(DOWNLOADS_DIR, f"{fid1}.%(ext)s")
            result = await _exec_dl(url, _yt_cookie_dl_opts(quality, out1), fid1)
            if result:
                print("[downloader] ✅ Cookies ishladi!")
                return result
            # Muvaffaqiyatsiz urinish qoldiqlarini tozalaymiz
            _cleanup_partial(fid1)
            print("[downloader] ⚠️ Cookies ishlamadi → 2-qatlam: Invidious")
        else:
            print("[downloader] Cookies fayl yo'q → to'g'ridan Invidious")

        # 2-qatlam: Invidious
        inv_url = _to_invidious(url)
        fid2 = uuid.uuid4().hex[:12]
        out2 = os.path.join(DOWNLOADS_DIR, f"{fid2}.%(ext)s")
        result = await _exec_dl(inv_url, _invidious_dl_opts(quality, out2), fid2)
        if result:
            print("[downloader] ✅ Invidious ishladi!")
        else:
            print("[downloader] ❌ Invidious ham ishlamadi")
        return result

    # ── Boshqa platformalar ────────────────────────────────────────────────────
    fid = uuid.uuid4().hex[:12]
    out = os.path.join(DOWNLOADS_DIR, f"{fid}.%(ext)s")
    opts = _invidious_dl_opts(quality, out)  # umumiy sozlamalar
    return await _exec_dl(url, opts, fid)


async def get_video_info(url: str) -> dict | None:
    url = _clean_url(url)
    loop = asyncio.get_running_loop()

    # ── Instagram ──────────────────────────────────────────────────────────────
    if _is_instagram(url):
        try:
            return await loop.run_in_executor(_executor, _run_info, url, _ig_info_opts())
        except Exception as e:
            print(f"[downloader] IG info xato: {e}")
            return None

    # ── YouTube ────────────────────────────────────────────────────────────────
    if _is_youtube_url(url):

        # 1-qatlam: Cookies bilan
        if _yt_cookies_ok():
            try:
                info = await loop.run_in_executor(
                    _executor, _run_info, url, _yt_cookie_info_opts()
                )
                if info:
                    return info
            except Exception as e:
                print(f"[downloader] Cookie info xato: {e}")

        # 2-qatlam: Invidious
        inv_url = _to_invidious(url)
        try:
            return await loop.run_in_executor(
                _executor, _run_info, inv_url, _invidious_info_opts()
            )
        except Exception as e:
            print(f"[downloader] Invidious info xato: {e}")
            return None

    # ── Boshqa ────────────────────────────────────────────────────────────────
    try:
        return await loop.run_in_executor(
            _executor, _run_info, url, _invidious_info_opts()
        )
    except Exception as e:
        print(f"[downloader] info xato: {e}")
        return None


def cleanup(filepath: str | None):
    if not filepath or filepath == "TOO_LARGE":
        return
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
    except Exception:
        pass
