import os
import re
import uuid
import base64
import asyncio
import tempfile
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import unquote

import yt_dlp

from config import (
    DOWNLOADS_DIR, MAX_FILE_SIZE_MB,
    IG_SESSION_ID, YT_SESSION_ID,
    YT_COOKIES, YT_COOKIES_B64, YT_COOKIES_FILE
)

os.makedirs(DOWNLOADS_DIR, exist_ok=True)
_executor = ThreadPoolExecutor(max_workers=3)

_IG_COOKIES_FILE: str | None = None
_YT_COOKIES_FILE: str | None = None


def _create_ig_cookies() -> str | None:
    if not IG_SESSION_ID:
        return None
    sid = unquote(IG_SESSION_ID.strip())
    uid = sid.split(":")[0] if ":" in sid else sid.split("%3A")[0]
    content = (
        "# Netscape HTTP Cookie File\n"
        f".instagram.com\tTRUE\t/\tTRUE\t2147483647\tsessionid\t{sid}\n"
        f".instagram.com\tTRUE\t/\tFALSE\t2147483647\tds_user_id\t{uid}\n"
    )
    tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8")
    tmp.write(content)
    tmp.close()
    print("[downloader] Instagram cookies ✅")
    return tmp.name


def _create_yt_cookies() -> str | None:
    # 1 — Base64 (eng ishonchli)
    if YT_COOKIES_B64 and YT_COOKIES_B64.strip():
        try:
            decoded = base64.b64decode(YT_COOKIES_B64.strip()).decode("utf-8")
            tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8")
            tmp.write(decoded)
            tmp.close()
            print("[downloader] YouTube Base64 cookies ✅")
            return tmp.name
        except Exception as e:
            print(f"[downloader] Base64 xato: {e}")

    # 2 — Render Secret File
    if os.path.exists(YT_COOKIES_FILE):
        print("[downloader] YouTube Secret File ✅")
        return YT_COOKIES_FILE

    # 3 — Env variable
    if YT_COOKIES and YT_COOKIES.strip():
        tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8")
        tmp.write(YT_COOKIES.strip())
        tmp.close()
        print("[downloader] YouTube YT_COOKIES ✅")
        return tmp.name

    # 4 — Session ID
    if YT_SESSION_ID and YT_SESSION_ID.strip():
        sid = unquote(YT_SESSION_ID.strip())
        content = (
            "# Netscape HTTP Cookie File\n"
            f".youtube.com\tTRUE\t/\tTRUE\t2147483647\tSID\t{sid}\n"
            f".youtube.com\tTRUE\t/\tTRUE\t2147483647\t__Secure-1PSID\t{sid}\n"
            f".youtube.com\tTRUE\t/\tTRUE\t2147483647\t__Secure-3PSID\t{sid}\n"
        )
        tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8")
        tmp.write(content)
        tmp.close()
        print("[downloader] YouTube session ID ✅")
        return tmp.name

    print("[downloader] ⚠️ YouTube cookies topilmadi")
    return None


_IG_COOKIES_FILE = _create_ig_cookies()
_YT_COOKIES_FILE = _create_yt_cookies()

FORMATS = {
    "360": "worst[ext=mp4]/worst",
    "720": (
        "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/"
        "bestvideo[height<=720]+bestaudio/"
        "best[height<=720][ext=mp4]/best[height<=720]/best"
    ),
    "1080": (
        "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/"
        "bestvideo[height<=1080]+bestaudio/"
        "best[height<=1080][ext=mp4]/best[height<=1080]/best"
    ),
    "4k": (
        "bestvideo[height<=2160][ext=mp4]+bestaudio[ext=m4a]/"
        "bestvideo[height<=2160]+bestaudio/best[height<=2160]/best"
    ),
}


def _clean_url(url: str) -> str:
    url = url.strip()
    for p in ['si', 'pp', 'feature']:
        url = re.sub(rf'[?&]{p}=[^&]*', '', url)
    return re.sub(r'[?&]$', '', url)


def _is_instagram(url: str) -> bool:
    return "instagram.com" in url or "instagr.am" in url


def _base_opts(url: str) -> dict:
    opts: dict = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "extractor_retries": 3,
    }
    if _is_instagram(url):
        if _IG_COOKIES_FILE:
            opts["cookiefile"] = _IG_COOKIES_FILE
        opts["http_headers"] = {
            "User-Agent": (
                "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
                "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 "
                "Mobile/15E148 Safari/604.1"
            ),
        }
    else:
        # Node.js orqali YouTube JavaScript challengeni hal qilish
        opts["extractor_args"] = {
            "youtube": {
                "player_client": ["ios", "web"],
            }
        }
        # JavaScript runtime ni yoqish
        opts["js_runtimes"] = ["node", "deno", "quickjs"]
        if _YT_COOKIES_FILE:
            opts["cookiefile"] = _YT_COOKIES_FILE
    return opts


def _build_dl_opts(url: str, quality: str, output_template: str) -> dict:
    opts = _base_opts(url)
    opts.update({
        "format": FORMATS.get(quality, FORMATS["720"]),
        "outtmpl": output_template,
        "merge_output_format": "mp4",
        "postprocessors": [
            {"key": "FFmpegVideoConvertor", "preferedformat": "mp4"}
        ],
    })
    return opts


def _run_download(url: str, opts: dict):
    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([url])


def _run_info(url: str, opts: dict) -> dict | None:
    with yt_dlp.YoutubeDL(opts) as ydl:
        return ydl.extract_info(url, download=False)


async def download_video(url: str, quality: str = "720") -> str | None:
    url = _clean_url(url)
    file_id = uuid.uuid4().hex[:12]
    out = os.path.join(DOWNLOADS_DIR, f"{file_id}.%(ext)s")
    opts = _build_dl_opts(url, quality, out)
    loop = asyncio.get_event_loop()
    try:
        await loop.run_in_executor(_executor, _run_download, url, opts)
    except Exception as e:
        print(f"[downloader] download error: {e}")
        return None
    for fname in os.listdir(DOWNLOADS_DIR):
        if fname.startswith(file_id):
            fpath = os.path.join(DOWNLOADS_DIR, fname)
            try:
                size_mb = os.path.getsize(fpath) / 1024 / 1024
            except OSError:
                return None
            if size_mb > MAX_FILE_SIZE_MB:
                os.remove(fpath)
                return "TOO_LARGE"
            return fpath
    return None


async def get_video_info(url: str) -> dict | None:
    url = _clean_url(url)
    opts = _base_opts(url)
    loop = asyncio.get_event_loop()
    try:
        return await loop.run_in_executor(_executor, _run_info, url, opts)
    except Exception as e:
        print(f"[downloader] info error: {e}")
        return None


def cleanup(filepath: str | None):
    if not filepath or filepath == "TOO_LARGE":
        return
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
    except Exception:
        pass
