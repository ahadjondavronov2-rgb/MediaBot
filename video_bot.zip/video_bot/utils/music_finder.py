import asyncio
import os

import aiohttp


async def find_music(video_path: str) -> dict | None:
    """
    Videodagi qo'shiqni AudD API orqali aniqlaydi.
    Hech qanday kutubxona o'rnatish shart emas — faqat aiohttp.
    """
    audio_path = video_path.rsplit(".", 1)[0] + "_audio.mp3"

    # ffmpeg orqali audio ajratish (faqat 15 soniya — Shazam uchun yetarli)
    cmd = (
        f'ffmpeg -i "{video_path}" '
        f'-vn -t 15 -ar 44100 -ac 1 -b:a 128k '
        f'"{audio_path}" -y -loglevel quiet'
    )
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    await proc.communicate()

    if not os.path.exists(audio_path):
        print("[music_finder] ffmpeg audio ajrata olmadi")
        return None

    try:
        async with aiohttp.ClientSession() as session:
            with open(audio_path, "rb") as f:
                form = aiohttp.FormData()
                form.add_field(
                    "file", f,
                    filename="audio.mp3",
                    content_type="audio/mpeg"
                )
                # AudD API — bepul, API kalit shart emas
                async with session.post(
                    "https://api.audd.io/",
                    data=form,
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as resp:
                    result = await resp.json()

        if result.get("status") == "success" and result.get("result"):
            track = result["result"]
            return {
                "title":      track.get("title", "Noma'lum"),
                "artist":     track.get("artist", "Noma'lum"),
                "shazam_url": track.get("song_link", ""),
            }

        print(f"[music_finder] AudD natija yo'q: {result}")
        return None

    except Exception as e:
        print(f"[music_finder] AudD xato: {e}")
        return None

    finally:
        if os.path.exists(audio_path):
            try:
                os.remove(audio_path)
            except Exception:
                pass
