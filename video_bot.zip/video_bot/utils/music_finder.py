import asyncio
import os
import uuid
import aiohttp
import yt_dlp

from config import DOWNLOADS_DIR


async def find_music(video_path: str) -> dict | None:
    """
    Videodagi qo'shiqni AudD API orqali aniqlaydi.
    Natija: {title, artist, shazam_url, yt_query}
    """
    audio_path = video_path.rsplit(".", 1)[0] + "_aud.mp3"

    # Faqat 20 soniya — tezroq tahlil
    cmd = (
        f'ffmpeg -i "{video_path}" -vn -t 20 '
        f'-ar 44100 -ac 1 -b:a 128k '
        f'"{audio_path}" -y -loglevel quiet'
    )
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    await proc.communicate()

    if not os.path.exists(audio_path):
        return None

    try:
        async with aiohttp.ClientSession() as session:
            with open(audio_path, "rb") as f:
                form = aiohttp.FormData()
                form.add_field("file", f, filename="audio.mp3", content_type="audio/mpeg")
                async with session.post(
                    "https://api.audd.io/",
                    data=form,
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as resp:
                    result = await resp.json()

        if result.get("status") == "success" and result.get("result"):
            track  = result["result"]
            title  = track.get("title", "Noma'lum")
            artist = track.get("artist", "Noma'lum")
            return {
                "title":      title,
                "artist":     artist,
                "shazam_url": track.get("song_link", ""),
                "yt_query":   f"ytsearch1:{artist} - {title} audio",
            }
        return None

    except Exception as e:
        print(f"[music] AudD xato: {e}")
        return None
    finally:
        if os.path.exists(audio_path):
            try: os.remove(audio_path)
            except: pass


async def download_mp3(yt_query: str, output_dir: str) -> str | None:
    """YouTube dan MP3 yuklab olish."""
    file_id = uuid.uuid4().hex[:10]
    output_template = os.path.join(output_dir, f"{file_id}.%(ext)s")

    opts = {
        "format": "bestaudio/best",
        "outtmpl": output_template,
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "extractor_args": {"youtube": {"player_client": ["ios", "web"]}},
        "postprocessors": [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": "192",
        }],
    }

    loop = asyncio.get_event_loop()

    def _dl():
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([yt_query])

    try:
        await loop.run_in_executor(None, _dl)
    except Exception as e:
        print(f"[music] MP3 xato: {e}")
        return None

    for fname in os.listdir(output_dir):
        if fname.startswith(file_id) and fname.endswith(".mp3"):
            return os.path.join(output_dir, fname)
    return None
