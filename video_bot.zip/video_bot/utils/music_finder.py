import asyncio
import os
import uuid
import aiohttp
import yt_dlp

from config import DOWNLOADS_DIR, YT_COOKIES_FILE

_CHROME_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/125.0.0.0 Safari/537.36"
)

# ─── Invidious instancelari ───────────────────────────────────────────────────
_INVIDIOUS_INSTANCES = [
    "https://inv.tux.pizza",
    "https://invidious.privacyredirect.com",
    "https://yt.artemislena.eu",
    "https://invidious.nikkosphere.com",
    "https://iv.melmac.space",
]


# ─── Cookies fayl tekshiruvi ──────────────────────────────────────────────────

def _yt_cookies_ok() -> bool:
    if not YT_COOKIES_FILE:
        return False
    try:
        return os.path.isfile(YT_COOKIES_FILE) and os.path.getsize(YT_COOKIES_FILE) > 100
    except OSError:
        return False


# ─── Invidious qidirish ───────────────────────────────────────────────────────

async def _invidious_search(query: str) -> str | None:
    """
    Invidious API orqali qo'shiq qidiradi.
    Cookies yo'q bo'lganda yoki ishlamaganda ishlatiladi.
    """
    params = {"q": query, "type": "video", "fields": "videoId", "page": "1"}
    async with aiohttp.ClientSession() as session:
        for instance in _INVIDIOUS_INSTANCES:
            try:
                async with session.get(
                    f"{instance}/api/v1/search",
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=8),
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data and isinstance(data, list) and len(data) > 0:
                            vid_id = data[0].get("videoId")
                            if vid_id:
                                print(f"[music] Invidious ✅ ({instance}): {vid_id}")
                                return f"invidious:{vid_id}"
            except Exception as e:
                print(f"[music] {instance} ishlamadi: {e}")
                continue
    print("[music] ⚠️ Barcha Invidious instancelar javob bermadi")
    return None


# ─── Musiqa aniqlash ─────────────────────────────────────────────────────────

async def find_music(video_path: str) -> dict | None:
    """Videodagi qo'shiqni AudD API orqali aniqlaydi."""
    audio_path = video_path.rsplit(".", 1)[0] + "_aud.mp3"
    cmd = (
        f'ffmpeg -i "{video_path}" -vn -t 20 '
        f'-ar 44100 -ac 1 -b:a 128k '
        f'"{audio_path}" -y -loglevel quiet'
    )
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    await proc.communicate()

    if not os.path.exists(audio_path):
        return None

    try:
        async with aiohttp.ClientSession() as session:
            with open(audio_path, "rb") as f:
                form = aiohttp.FormData()
                form.add_field("file", f, filename="audio.mp3", content_type="audio/mpeg")
                async with session.post(
                    "https://api.audd.io/",
                    data=form,
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as resp:
                    result = await resp.json()

        if result.get("status") == "success" and result.get("result"):
            track  = result["result"]
            title  = track.get("title", "Noma'lum")
            artist = track.get("artist", "Noma'lum")
            return {
                "title":      title,
                "artist":     artist,
                "shazam_url": track.get("song_link", ""),
                "yt_query":   f"{artist} - {title} audio",
            }
        return None

    except Exception as e:
        print(f"[music] AudD xato: {e}")
        return None
    finally:
        if os.path.exists(audio_path):
            try: os.remove(audio_path)
            except: pass


# ─── MP3 yuklab olish ─────────────────────────────────────────────────────────

async def download_mp3(search_query: str, output_dir: str) -> str | None:
    """
    3 qatlam:
    1. Cookies mavjud → ytsearch + cookies (to'g'ridan YouTube)
    2. Cookies yo'q yoki xato → Invidious search → invidious:VIDEO_ID
    3. Invidious ham xato → ytsearch fallback (oxirgi imkon)
    """
    # Eski ytsearch1: prefiksini tozalaymiz (eski DB yozuvlari uchun)
    clean_query = search_query.removeprefix("ytsearch1:").strip()

    file_id  = uuid.uuid4().hex[:10]
    out_tmpl = os.path.join(output_dir, f"{file_id}.%(ext)s")
    loop     = asyncio.get_running_loop()

    def _build_mp3_opts(url: str, use_cookies: bool = False) -> dict:
        opts: dict = {
            "format": "bestaudio/best",
            "outtmpl": out_tmpl,
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }],
        }
        if use_cookies and _yt_cookies_ok():
            opts["cookiefile"]    = YT_COOKIES_FILE
            opts["http_headers"]  = {"User-Agent": _CHROME_UA}
        return opts

    def _dl(url: str, use_cookies: bool = False):
        with yt_dlp.YoutubeDL(_build_mp3_opts(url, use_cookies)) as ydl:
            ydl.download([url])

    def _find_mp3() -> str | None:
        for fname in os.listdir(output_dir):
            if fname.startswith(file_id) and fname.endswith(".mp3"):
                return os.path.join(output_dir, fname)
        return None

    # 1-qatlam: Cookies bilan ytsearch
    if _yt_cookies_ok():
        print(f"[music] 1-qatlam: Cookies bilan: {clean_query}")
        try:
            await loop.run_in_executor(
                None, _dl, f"ytsearch1:{clean_query}", True
            )
            result = _find_mp3()
            if result:
                print("[music] ✅ Cookies MP3 ishladi!")
                return result
        except Exception as e:
            print(f"[music] Cookies MP3 xato: {e}")

    # 2-qatlam: Invidious search
    print(f"[music] 2-qatlam: Invidious search...")
    inv_url = await _invidious_search(clean_query)
    if inv_url:
        try:
            await loop.run_in_executor(None, _dl, inv_url, False)
            result = _find_mp3()
            if result:
                print("[music] ✅ Invidious MP3 ishladi!")
                return result
        except Exception as e:
            print(f"[music] Invidious MP3 xato: {e}")

    # 3-qatlam: oxirgi fallback — to'g'ridan ytsearch
    print(f"[music] 3-qatlam: ytsearch fallback...")
    try:
        await loop.run_in_executor(None, _dl, f"ytsearch1:{clean_query}", False)
        return _find_mp3()
    except Exception as e:
        print(f"[music] Fallback MP3 xato: {e}")
        return None
