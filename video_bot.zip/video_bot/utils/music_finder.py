import asyncio
import os
import aiohttp


async def find_music(video_path: str) -> dict | None:
    """
    Videodagi qo'shiqni AudD API orqali aniqlaydi.
    API kalit shart emas — bepul ishlaydi.
    """
    audio_path = video_path.rsplit(".", 1)[0] + "_audio.mp3"

    # ffmpeg — videoning faqat birinchi 15 soniyasini audio ga o'girish
    cmd = (
        f'ffmpeg -i "{video_path}" -vn -t 15 '
        f'-ar 44100 -ac 1 -b:a 128k '
        f'"{audio_path}" -y -loglevel quiet'
    )
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    await proc.communicate()

    if not os.path.exists(audio_path):
        print("[music] ffmpeg audio ajrata olmadi")
        return None

    result = None
    try:
        async with aiohttp.ClientSession() as session:
            with open(audio_path, "rb") as f:
                form = aiohttp.FormData()
                form.add_field(
                    "file", f,
                    filename="audio.mp3",
                    content_type="audio/mpeg",
                )
                async with session.post(
                    "https://api.audd.io/",
                    data=form,
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as resp:
                    result = await resp.json()

        if result.get("status") == "success" and result.get("result"):
            track = result["result"]
            return {
                "title":      track.get("title", "Noma'lum"),
                "artist":     track.get("artist", "Noma'lum"),
                "shazam_url": track.get("song_link", ""),
            }
        return None

    except Exception as e:
        print(f"[music] AudD xato: {e}")
        return None
    finally:
        if os.path.exists(audio_path):
            try:
                os.remove(audio_path)
            except Exception:
                pass
