import asyncio
import os

from shazamio import Shazam


async def find_music(video_path: str) -> dict | None:
    """
    Extract audio from video and recognise the song via Shazam.
    Returns dict with title/artist/url or None if not found.
    """
    audio_path = video_path.rsplit(".", 1)[0] + "_audio.mp3"

    # Extract audio with ffmpeg
    cmd = (
        f'ffmpeg -i "{video_path}" -vn -ar 44100 -ac 2 -b:a 128k '
        f'"{audio_path}" -y -loglevel quiet'
    )
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    await proc.communicate()

    if not os.path.exists(audio_path):
        return None

    try:
        shazam = Shazam()
        result = await shazam.recognize(audio_path)
    except Exception as e:
        print(f"[music_finder] Shazam error: {e}")
        return None
    finally:
        if os.path.exists(audio_path):
            os.remove(audio_path)

    track = result.get("track") if result else None
    if not track:
        return None

    return {
        "title": track.get("title", "Noma'lum"),
        "artist": track.get("subtitle", "Noma'lum"),
        "shazam_url": track.get("url", ""),
        "cover": track.get("images", {}).get("coverart", ""),
    }
