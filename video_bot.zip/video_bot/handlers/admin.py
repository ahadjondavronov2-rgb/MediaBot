import asyncio

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery

from config import ADMIN_IDS
from database import (
    get_users_count, get_today_active_count, get_downloads_count,
    get_all_user_ids, get_channels,
    add_channel, remove_channel,
    ban_user, unban_user,
)
from keyboards.admin_kb import admin_main_kb, admin_channels_kb, admin_ban_kb

router = Router()


class AdminFSM(StatesGroup):
    add_ch_id   = State()
    add_ch_name = State()
    add_ch_link = State()
    broadcast   = State()
    ban_id      = State()
    unban_id    = State()


def _is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


# ── /admin ────────────────────────────────────────────────────────────────────

@router.message(Command("admin"))
async def cmd_admin(message: Message):
    if not _is_admin(message.from_user.id):
        return  # boshqa foydalanuvchiga hech narsa ko'rinmaydi
    await message.answer(
        "🛠 <b>Admin Panel</b>\n\nKerakli bo'limni tanlang:",
        reply_markup=admin_main_kb(),
        parse_mode="HTML",
    )


# ── Statistika ────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_stats")
async def cb_stats(callback: CallbackQuery):
    if not _is_admin(callback.from_user.id):
        return
    total  = await get_users_count()
    active = await get_today_active_count()
    dl     = await get_downloads_count()
    await callback.message.edit_text(
        "📊 <b>Bot Statistikasi</b>\n\n"
        f"👥 Jami foydalanuvchilar : <b>{total}</b>\n"
        f"🟢 Bugun faollar         : <b>{active}</b>\n"
        f"📥 Jami yuklab olingan   : <b>{dl}</b>",
        reply_markup=admin_main_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


# ── Kanallar ──────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_channels")
async def cb_channels(callback: CallbackQuery):
    if not _is_admin(callback.from_user.id):
        return
    channels = await get_channels()
    await callback.message.edit_text(
        "📢 <b>Kanal / Guruh boshqaruvi</b>\n\n"
        "❌ — kanalnu o'chirish\n"
        "➕ — yangi kanal qo'shish",
        reply_markup=admin_channels_kb(channels),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data.startswith("del_ch:"))
async def cb_del_channel(callback: CallbackQuery):
    if not _is_admin(callback.from_user.id):
        return
    ch_id = callback.data.split(":", 1)[1]
    await remove_channel(ch_id)
    channels = await get_channels()
    try:
        await callback.message.edit_reply_markup(reply_markup=admin_channels_kb(channels))
    except Exception:
        pass
    await callback.answer("✅ Kanal o'chirildi")


@router.callback_query(F.data == "add_ch")
async def cb_add_ch(callback: CallbackQuery, state: FSMContext):
    if not _is_admin(callback.from_user.id):
        return
    await callback.message.answer(
        "📢 Kanal yoki guruh <b>ID</b> sini yuboring.\n\n"
        "Misol: <code>-1001234567890</code>\n\n"
        "<i>Botni kanalga admin qilib qo'shganingizni tekshiring!</i>",
        parse_mode="HTML",
    )
    await state.set_state(AdminFSM.add_ch_id)
    await callback.answer()


@router.message(AdminFSM.add_ch_id)
async def fsm_ch_id(message: Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    ch_id = message.text.strip() if message.text else ""
    if not ch_id:
        await message.answer("❌ ID bo'sh bo'lmasin.")
        return
    await state.update_data(ch_id=ch_id)
    await message.answer("Kanal/guruh <b>nomini</b> yuboring:", parse_mode="HTML")
    await state.set_state(AdminFSM.add_ch_name)


@router.message(AdminFSM.add_ch_name)
async def fsm_ch_name(message: Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    await state.update_data(ch_name=message.text.strip() if message.text else "")
    await message.answer(
        "Kanal/guruh <b>havolasini</b> yuboring:\n"
        "Misol: <code>https://t.me/mychannel</code>",
        parse_mode="HTML",
    )
    await state.set_state(AdminFSM.add_ch_link)


@router.message(AdminFSM.add_ch_link)
async def fsm_ch_link(message: Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    data = await state.get_data()
    link = message.text.strip() if message.text else ""
    await add_channel(data["ch_id"], data["ch_name"], link)
    await state.clear()
    await message.answer(
        f"✅ <b>{data['ch_name']}</b> qo'shildi!",
        parse_mode="HTML",
    )


# ── Broadcast ─────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_broadcast")
async def cb_broadcast(callback: CallbackQuery, state: FSMContext):
    if not _is_admin(callback.from_user.id):
        return
    await callback.message.answer(
        "📣 Barcha foydalanuvchilarga yuboriladigan xabarni yozing:\n"
        "<i>(HTML formatlash ishlaydi: &lt;b&gt;, &lt;i&gt;, &lt;a&gt;)</i>",
        parse_mode="HTML",
    )
    await state.set_state(AdminFSM.broadcast)
    await callback.answer()


@router.message(AdminFSM.broadcast)
async def fsm_broadcast(message: Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    await state.clear()

    user_ids = await get_all_user_ids()
    total = len(user_ids)
    sent = failed = 0

    progress = await message.answer(f"📣 Yuborilmoqda... 0 / {total}")

    for i, uid in enumerate(user_ids, 1):
        try:
            await message.bot.send_message(
                uid, message.text or "", parse_mode="HTML"
            )
            sent += 1
        except Exception:
            failed += 1

        if i % 30 == 0:
            try:
                await progress.edit_text(f"📣 Yuborilmoqda... {i} / {total}")
            except Exception:
                pass
        await asyncio.sleep(0.05)  # flood limitdan himoya

    try:
        await progress.edit_text(
            "✅ <b>Broadcast tugadi!</b>\n\n"
            f"✅ Yuborildi  : <b>{sent}</b>\n"
            f"❌ Xatolik   : <b>{failed}</b>",
            parse_mode="HTML",
        )
    except Exception:
        pass


# ── Ban / Unban ───────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_ban_menu")
async def cb_ban_menu(callback: CallbackQuery):
    if not _is_admin(callback.from_user.id):
        return
    await callback.message.edit_text(
        "🚫 <b>Ban / Unban</b>\n\nAmalni tanlang:",
        reply_markup=admin_ban_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "do_ban")
async def cb_do_ban(callback: CallbackQuery, state: FSMContext):
    if not _is_admin(callback.from_user.id):
        return
    await callback.message.answer(
        "🚫 Ban qilmoqchi bo'lgan foydalanuvchi <b>Telegram ID</b> sini yuboring:",
        parse_mode="HTML",
    )
    await state.set_state(AdminFSM.ban_id)
    await callback.answer()


@router.message(AdminFSM.ban_id)
async def fsm_ban(message: Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    text = message.text.strip() if message.text else ""
    if not text.isdigit():
        await message.answer("❌ Faqat raqam kiriting.")
        return
    uid = int(text)
    await ban_user(uid)
    await state.clear()
    await message.answer(
        f"✅ <code>{uid}</code> ban qilindi.",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "do_unban")
async def cb_do_unban(callback: CallbackQuery, state: FSMContext):
    if not _is_admin(callback.from_user.id):
        return
    await callback.message.answer(
        "✅ Unban qilmoqchi bo'lgan foydalanuvchi <b>Telegram ID</b> sini yuboring:",
        parse_mode="HTML",
    )
    await state.set_state(AdminFSM.unban_id)
    await callback.answer()


@router.message(AdminFSM.unban_id)
async def fsm_unban(message: Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    text = message.text.strip() if message.text else ""
    if not text.isdigit():
        await message.answer("❌ Faqat raqam kiriting.")
        return
    uid = int(text)
    await unban_user(uid)
    await state.clear()
    await message.answer(
        f"✅ <code>{uid}</code> unban qilindi.",
        parse_mode="HTML",
    )


# ── Orqaga ────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_back")
async def cb_back(callback: CallbackQuery, state: FSMContext):
    if not _is_admin(callback.from_user.id):
        return
    await state.clear()
    try:
        await callback.message.edit_text(
            "🛠 <b>Admin Panel</b>",
            reply_markup=admin_main_kb(),
            parse_mode="HTML",
        )
    except Exception:
        pass
    await callback.answer()
