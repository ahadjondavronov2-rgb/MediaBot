import asyncio
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

from config import ADMIN_IDS
from database import (
    get_users_count, get_today_active_count, get_downloads_count,
    get_all_user_ids, get_channels,
    add_channel, remove_channel,
    ban_user, unban_user,
)

router = Router()


class AdminFSM(StatesGroup):
    add_ch_id   = State()
    add_ch_name = State()
    add_ch_link = State()
    broadcast   = State()
    ban_id      = State()
    unban_id    = State()


def _is_admin(uid: int) -> bool:
    return uid in ADMIN_IDS


def admin_main_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 Statistika",           callback_data="adm_stats")],
        [InlineKeyboardButton(text="📢 Kanal / Guruh",        callback_data="adm_channels")],
        [InlineKeyboardButton(text="📣 Barchaga xabar",       callback_data="adm_broadcast")],
        [InlineKeyboardButton(text="🚫 Ban  |  ✅ Unban",     callback_data="adm_ban_menu")],
    ])


def channels_kb(channels: list) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=f"❌ {ch[2]}", callback_data=f"del_ch:{ch[1]}")]
        for ch in channels
    ]
    rows.append([InlineKeyboardButton(text="➕ Yangi kanal/guruh qo'shish", callback_data="add_ch")])
    rows.append([InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def ban_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🚫 Ban",    callback_data="do_ban")],
        [InlineKeyboardButton(text="✅ Unban",  callback_data="do_unban")],
        [InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_back")],
    ])


# ── /admin ────────────────────────────────────────────────────────────────────

@router.message(Command("admin"))
async def cmd_admin(message: Message):
    if not _is_admin(message.from_user.id):
        return
    await message.answer(
        "🛠 <b>Admin Panel</b>\n\nKerakli bo'limni tanlang:",
        reply_markup=admin_main_kb(),
        parse_mode="HTML",
    )


# ── Statistika ────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_stats")
async def cb_stats(callback: CallbackQuery):
    if not _is_admin(callback.from_user.id):
        return
    total   = await get_users_count()
    active  = await get_today_active_count()
    dl      = await get_downloads_count()
    channels = await get_channels()

    await callback.message.edit_text(
        "📊 <b>Bot Statistikasi</b>\n\n"
        f"👥 Jami foydalanuvchilar : <b>{total}</b>\n"
        f"🟢 Bugun faollar         : <b>{active}</b>\n"
        f"📥 Jami yuklab olingan   : <b>{dl}</b>\n"
        f"📢 Ulangan kanallar      : <b>{len(channels)}</b>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_back")]
        ]),
        parse_mode="HTML",
    )
    await callback.answer()


# ── Kanallar ──────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_channels")
async def cb_channels(callback: CallbackQuery):
    if not _is_admin(callback.from_user.id):
        return
    channels = await get_channels()
    text = (
        "📢 <b>Kanal / Guruh boshqaruvi</b>\n\n"
        f"Hozir ulangan: <b>{len(channels)} ta</b>\n\n"
        "❌ — o'chirish\n"
        "➕ — yangi qo'shish"
    )
    await callback.message.edit_text(text, reply_markup=channels_kb(channels), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("del_ch:"))
async def cb_del_ch(callback: CallbackQuery):
    if not _is_admin(callback.from_user.id):
        return
    ch_id = callback.data.split(":", 1)[1]
    await remove_channel(ch_id)
    channels = await get_channels()
    try:
        await callback.message.edit_reply_markup(reply_markup=channels_kb(channels))
    except Exception:
        pass
    await callback.answer("✅ Kanal o'chirildi")


@router.callback_query(F.data == "add_ch")
async def cb_add_ch(callback: CallbackQuery, state: FSMContext):
    if not _is_admin(callback.from_user.id):
        return
    await callback.message.answer(
        "📢 Kanal/guruh <b>ID</b> sini yuboring.\n\n"
        "Misol: <code>-1001234567890</code>\n\n"
        "<i>⚠️ Botni kanalga admin qilib qo'shing!</i>",
        parse_mode="HTML",
    )
    await state.set_state(AdminFSM.add_ch_id)
    await callback.answer()


@router.message(AdminFSM.add_ch_id)
async def fsm_ch_id(message: Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    await state.update_data(ch_id=message.text.strip() if message.text else "")
    await message.answer("Kanal/guruh <b>nomini</b> yuboring:", parse_mode="HTML")
    await state.set_state(AdminFSM.add_ch_name)


@router.message(AdminFSM.add_ch_name)
async def fsm_ch_name(message: Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    await state.update_data(ch_name=message.text.strip() if message.text else "")
    await message.answer(
        "Kanal/guruh <b>havolasini</b> yuboring:\n"
        "Misol: <code>https://t.me/mychannel</code>",
        parse_mode="HTML",
    )
    await state.set_state(AdminFSM.add_ch_link)


@router.message(AdminFSM.add_ch_link)
async def fsm_ch_link(message: Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    data = await state.get_data()
    link = message.text.strip() if message.text else ""
    await add_channel(data["ch_id"], data["ch_name"], link)
    await state.clear()
    await message.answer(
        f"✅ <b>{data['ch_name']}</b> muvaffaqiyatli qo'shildi!",
        parse_mode="HTML",
    )


# ── Broadcast ─────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_broadcast")
async def cb_broadcast(callback: CallbackQuery, state: FSMContext):
    if not _is_admin(callback.from_user.id):
        return
    total = await get_users_count()
    await callback.message.answer(
        f"📣 <b>Broadcast</b>\n\n"
        f"Jami foydalanuvchilar: <b>{total} ta</b>\n\n"
        f"Barchaga yuboriladigan xabarni yozing:\n"
        f"<i>(HTML: &lt;b&gt;, &lt;i&gt;, &lt;a&gt; ishlaydi)</i>",
        parse_mode="HTML",
    )
    await state.set_state(AdminFSM.broadcast)
    await callback.answer()


@router.message(AdminFSM.broadcast)
async def fsm_broadcast(message: Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    await state.clear()
    user_ids = await get_all_user_ids()
    total = len(user_ids)
    sent = failed = 0
    progress = await message.answer(f"📣 Yuborilmoqda... 0 / {total}")

    for i, uid in enumerate(user_ids, 1):
        try:
            await message.bot.send_message(uid, message.text or "", parse_mode="HTML")
            sent += 1
        except Exception:
            failed += 1
        if i % 30 == 0:
            try:
                await progress.edit_text(f"📣 Yuborilmoqda... {i} / {total}")
            except Exception:
                pass
        await asyncio.sleep(0.05)

    try:
        await progress.edit_text(
            f"✅ <b>Broadcast tugadi!</b>\n\n"
            f"✅ Yuborildi  : <b>{sent}</b>\n"
            f"❌ Xatolik   : <b>{failed}</b>",
            parse_mode="HTML",
        )
    except Exception:
        pass


# ── Ban / Unban ───────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_ban_menu")
async def cb_ban_menu(callback: CallbackQuery):
    if not _is_admin(callback.from_user.id):
        return
    await callback.message.edit_text(
        "🚫 <b>Ban / Unban</b>",
        reply_markup=ban_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "do_ban")
async def cb_ban(callback: CallbackQuery, state: FSMContext):
    if not _is_admin(callback.from_user.id):
        return
    await callback.message.answer("🚫 Ban qilish uchun <b>Telegram ID</b> yuboring:", parse_mode="HTML")
    await state.set_state(AdminFSM.ban_id)
    await callback.answer()


@router.message(AdminFSM.ban_id)
async def fsm_ban(message: Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    text = message.text.strip() if message.text else ""
    if not text.isdigit():
        await message.answer("❌ Faqat raqam kiriting.")
        return
    await ban_user(int(text))
    await state.clear()
    await message.answer(f"✅ <code>{text}</code> ban qilindi.", parse_mode="HTML")


@router.callback_query(F.data == "do_unban")
async def cb_unban(callback: CallbackQuery, state: FSMContext):
    if not _is_admin(callback.from_user.id):
        return
    await callback.message.answer("✅ Unban qilish uchun <b>Telegram ID</b> yuboring:", parse_mode="HTML")
    await state.set_state(AdminFSM.unban_id)
    await callback.answer()


@router.message(AdminFSM.unban_id)
async def fsm_unban(message: Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    text = message.text.strip() if message.text else ""
    if not text.isdigit():
        await message.answer("❌ Faqat raqam kiriting.")
        return
    await unban_user(int(text))
    await state.clear()
    await message.answer(f"✅ <code>{text}</code> unban qilindi.", parse_mode="HTML")


# ── Orqaga ────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_back")
async def cb_back(callback: CallbackQuery, state: FSMContext):
    if not _is_admin(callback.from_user.id):
        return
    await state.clear()
    try:
        await callback.message.edit_text(
            "🛠 <b>Admin Panel</b>",
            reply_markup=admin_main_kb(),
            parse_mode="HTML",
        )
    except Exception:
        pass
    await callback.answer()
