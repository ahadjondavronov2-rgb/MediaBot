import asyncio

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery

from config import ADMIN_IDS
from database import (
    get_users_count, get_today_active_count, get_downloads_count,
    get_all_user_ids, get_channels,
    add_channel, remove_channel,
    ban_user, unban_user,
)
from keyboards.admin_kb import admin_main_kb, admin_channels_kb, admin_ban_kb, back_kb

router = Router()


# ── FSM States ────────────────────────────────────────────────────────────────

class AdminFSM(StatesGroup):
    add_ch_id   = State()
    add_ch_name = State()
    add_ch_link = State()
    broadcast   = State()
    ban_id      = State()
    unban_id    = State()


# ── Guard ─────────────────────────────────────────────────────────────────────

def admin_only(user_id: int) -> bool:
    return user_id in ADMIN_IDS


# ── /admin command ────────────────────────────────────────────────────────────

@router.message(Command("admin"))
async def cmd_admin(message: Message):
    if not admin_only(message.from_user.id):
        return
    await message.answer(
        "🛠 <b>Admin Panel</b>\n\nKerakli bo'limni tanlang:",
        reply_markup=admin_main_kb(),
        parse_mode="HTML",
    )


# ── Statistics ────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_stats")
async def cb_stats(callback: CallbackQuery):
    if not admin_only(callback.from_user.id):
        return
    total   = await get_users_count()
    active  = await get_today_active_count()
    dl      = await get_downloads_count()
    await callback.message.edit_text(
        f"📊 <b>Bot Statistikasi</b>\n\n"
        f"👥 Jami foydalanuvchilar : <b>{total}</b>\n"
        f"🟢 Bugun faollar         : <b>{active}</b>\n"
        f"📥 Jami yuklab olingan   : <b>{dl}</b>",
        reply_markup=admin_main_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


# ── Channels management ───────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_channels")
async def cb_channels(callback: CallbackQuery):
    if not admin_only(callback.from_user.id):
        return
    channels = await get_channels()
    await callback.message.edit_text(
        "📢 <b>Kanal / Guruh boshqaruvi</b>\n\n"
        "❌ tugmasi — kanalnu o'chirish\n"
        "➕ tugmasi — yangi kanal qo'shish",
        reply_markup=admin_channels_kb(channels),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data.startswith("del_ch:"))
async def cb_del_channel(callback: CallbackQuery):
    if not admin_only(callback.from_user.id):
        return
    ch_id = callback.data.split(":", 1)[1]
    await remove_channel(ch_id)
    channels = await get_channels()
    await callback.message.edit_reply_markup(reply_markup=admin_channels_kb(channels))
    await callback.answer("✅ Kanal o'chirildi")


@router.callback_query(F.data == "add_ch")
async def cb_add_channel_start(callback: CallbackQuery, state: FSMContext):
    if not admin_only(callback.from_user.id):
        return
    await callback.message.answer(
        "📢 Kanal yoki guruh <b>ID</b> sini yuboring.\n\n"
        "Misol: <code>-1001234567890</code>\n\n"
        "<i>Botni kanalga admin qilib qo'shganingizni tekshiring!</i>",
        parse_mode="HTML",
    )
    await state.set_state(AdminFSM.add_ch_id)
    await callback.answer()


@router.message(AdminFSM.add_ch_id)
async def fsm_add_ch_id(message: Message, state: FSMContext):
    if not admin_only(message.from_user.id):
        return
    await state.update_data(ch_id=message.text.strip())
    await message.answer("Kanal/guruh <b>nomini</b> yuboring (masalan: My Channel):", parse_mode="HTML")
    await state.set_state(AdminFSM.add_ch_name)


@router.message(AdminFSM.add_ch_name)
async def fsm_add_ch_name(message: Message, state: FSMContext):
    if not admin_only(message.from_user.id):
        return
    await state.update_data(ch_name=message.text.strip())
    await message.answer(
        "Kanal/guruh <b>havolasini</b> yuboring:\n"
        "Misol: <code>https://t.me/mychannel</code>",
        parse_mode="HTML",
    )
    await state.set_state(AdminFSM.add_ch_link)


@router.message(AdminFSM.add_ch_link)
async def fsm_add_ch_link(message: Message, state: FSMContext):
    if not admin_only(message.from_user.id):
        return
    data = await state.get_data()
    await add_channel(data["ch_id"], data["ch_name"], message.text.strip())
    await state.clear()
    await message.answer(
        f"✅ Kanal muvaffaqiyatli qo'shildi!\n"
        f"📢 <b>{data['ch_name']}</b>",
        parse_mode="HTML",
    )


# ── Broadcast ─────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_broadcast")
async def cb_broadcast_start(callback: CallbackQuery, state: FSMContext):
    if not admin_only(callback.from_user.id):
        return
    await callback.message.answer(
        "📣 Barcha foydalanuvchilarga yuboriladigan xabarni yozing:\n"
        "<i>(HTML formatlash qo'llab-quvvatlanadi)</i>",
        parse_mode="HTML",
    )
    await state.set_state(AdminFSM.broadcast)
    await callback.answer()


@router.message(AdminFSM.broadcast)
async def fsm_broadcast(message: Message, state: FSMContext):
    if not admin_only(message.from_user.id):
        return
    await state.clear()

    user_ids = await get_all_user_ids()
    total = len(user_ids)
    sent = failed = 0

    progress = await message.answer(f"📣 Yuborilmoqda... 0 / {total}")

    for i, uid in enumerate(user_ids, 1):
        try:
            await message.bot.send_message(uid, message.text, parse_mode="HTML")
            sent += 1
        except Exception:
            failed += 1

        if i % 25 == 0:
            await progress.edit_text(f"📣 Yuborilmoqda... {i} / {total}")
        await asyncio.sleep(0.05)  # avoid flood limits

    await progress.edit_text(
        f"✅ <b>Broadcast tugadi!</b>\n\n"
        f"✅ Muvaffaqiyatli : {sent}\n"
        f"❌ Xatolik        : {failed}",
        parse_mode="HTML",
    )


# ── Ban / Unban ───────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_ban_menu")
async def cb_ban_menu(callback: CallbackQuery):
    if not admin_only(callback.from_user.id):
        return
    await callback.message.edit_text(
        "🚫 <b>Ban / Unban</b>\n\nAmalni tanlang:",
        reply_markup=admin_ban_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "do_ban")
async def cb_do_ban(callback: CallbackQuery, state: FSMContext):
    if not admin_only(callback.from_user.id):
        return
    await callback.message.answer("🚫 Ban qilmoqchi bo'lgan foydalanuvchi <b>ID</b> sini yuboring:", parse_mode="HTML")
    await state.set_state(AdminFSM.ban_id)
    await callback.answer()


@router.message(AdminFSM.ban_id)
async def fsm_ban(message: Message, state: FSMContext):
    if not admin_only(message.from_user.id):
        return
    try:
        uid = int(message.text.strip())
        await ban_user(uid)
        await state.clear()
        await message.answer(f"✅ Foydalanuvchi <code>{uid}</code> ban qilindi.", parse_mode="HTML")
    except ValueError:
        await message.answer("❌ Noto'g'ri ID formati. Raqam kiriting.")


@router.callback_query(F.data == "do_unban")
async def cb_do_unban(callback: CallbackQuery, state: FSMContext):
    if not admin_only(callback.from_user.id):
        return
    await callback.message.answer("✅ Unban qilmoqchi bo'lgan foydalanuvchi <b>ID</b> sini yuboring:", parse_mode="HTML")
    await state.set_state(AdminFSM.unban_id)
    await callback.answer()


@router.message(AdminFSM.unban_id)
async def fsm_unban(message: Message, state: FSMContext):
    if not admin_only(message.from_user.id):
        return
    try:
        uid = int(message.text.strip())
        await unban_user(uid)
        await state.clear()
        await message.answer(f"✅ Foydalanuvchi <code>{uid}</code> unban qilindi.", parse_mode="HTML")
    except ValueError:
        await message.answer("❌ Noto'g'ri ID formati.")


# ── Back button ───────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm_back")
async def cb_back(callback: CallbackQuery, state: FSMContext):
    if not admin_only(callback.from_user.id):
        return
    await state.clear()
    await callback.message.edit_text(
        "🛠 <b>Admin Panel</b>",
        reply_markup=admin_main_kb(),
        parse_mode="HTML",
    )
    await callback.answer()
