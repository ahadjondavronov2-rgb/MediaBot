from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from middlewares.subscription import _not_subscribed_channels

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    name = message.from_user.first_name or "Do'st"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📸 Instagram", callback_data="hi_ig"),
            InlineKeyboardButton(text="▶️ YouTube", callback_data="hi_yt"),
        ],
        [
            InlineKeyboardButton(text="🎵 Qo'shiq topish + MP3", callback_data="hi_music"),
        ],
    ])
    await message.answer(
        f"🎬 <b>Salom, {name}!</b>\n\n"
        f"⚡️ <b>MediaVault</b> — eng tezkor video yuklovchi bot!\n\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"📸 <b>Instagram</b>\n"
        f"   Reels · Post · Story\n"
        f"   720p avtomatik + 1080p / 4K\n\n"
        f"▶️ <b>YouTube</b>\n"
        f"   Video · Shorts · 720p / 1080p / 4K\n\n"
        f"🎵 <b>Qo'shiq topish</b>\n"
        f"   Video ichidagi musiqani aniqlaydi\n"
        f"   Nom · Artist · MP3 yuklab beradi\n"
        f"━━━━━━━━━━━━━━━━━━━\n\n"
        f"👇 <b>Shunchaki link yuboring!</b>",
        parse_mode="HTML",
        reply_markup=kb,
    )


@router.callback_query(F.data == "hi_ig")
async def hi_ig(callback: CallbackQuery):
    await callback.answer()
    await callback.message.answer(
        "📸 <b>Instagram yuklab olish</b>\n\n"
        "• Videoni oching → <b>Ulashish → Nusxalash</b>\n"
        "• Havolani menga yuboring\n\n"
        "✅ 720p avtomatik yuklanadi\n"
        "✅ 1080p / 4K / 🎵 tugmalar chiqadi",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "hi_yt")
async def hi_yt(callback: CallbackQuery):
    await callback.answer()
    await callback.message.answer(
        "▶️ <b>YouTube yuklab olish</b>\n\n"
        "• Videoni oching → <b>Ulashish → Nusxalash</b>\n"
        "• Havolani menga yuboring\n\n"
        "✅ 720p / 1080p / 4K tanlaysiz\n"
        "✅ Shorts ham ishlaydi\n"
        "✅ 🎵 Qo'shiq topish tugmasi",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "hi_music")
async def hi_music(callback: CallbackQuery):
    await callback.answer()
    await callback.message.answer(
        "🎵 <b>Qo'shiq topish + MP3</b>\n\n"
        "• Instagram yoki YouTube linkini yuboring\n"
        "• <b>🎵 Qo'shiq topish</b> tugmasini bosing\n"
        "• Qo'shiq nomi va artist chiqadi\n"
        "• <b>🎧 MP3 yuklab olish</b> tugmasini bosing\n\n"
        "⚡️ Dunyodagi istalgan qo'shiqni tezda topadi!",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "check_sub")
async def check_sub(callback: CallbackQuery):
    missing = await _not_subscribed_channels(callback.bot, callback.from_user.id)
    if missing:
        await callback.answer("❌ Hali a'zo bo'lmadingiz!", show_alert=True)
    else:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(
            "✅ <b>Rahmat!</b> Endi link yuboring! 🚀",
            parse_mode="HTML",
        )


@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(
        "❓ <b>Yordam</b>\n\n"
        "Instagram yoki YouTube havolasini yuboring.\n"
        "Akkaunt ochiq (public) bo'lishi kerak.\n"
        "Maksimal fayl: 50 MB.",
        parse_mode="HTML",
    )


@router.message()
async def unknown(message: Message):
    text = message.text or ""
    if text.startswith("http"):
        await message.answer(
            "❌ Bu havola qo'llab-quvvatlanmaydi.\n\n"
            "✅ Faqat Instagram va YouTube havolalari."
        )
    else:
        await message.answer(
            "📎 Instagram yoki YouTube linkini yuboring!\n"
            "/start — bosh menyu"
        )
