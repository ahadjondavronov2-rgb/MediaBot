from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery
from middlewares.subscription import _not_subscribed_channels

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    name = message.from_user.first_name or "Do'st"
    await message.answer(
        f"Salom, <b>{name}</b>! 👋\n\n"
        f"Men — <b>MediaVault Bot</b>\n\n"
        f"📸 <b>Instagram</b> — Reels, Post, Story\n"
        f"▶️ <b>YouTube</b> — Video, Shorts\n"
        f"🎵 <b>Qo'shiq topish</b> + 🎧 MP3\n\n"
        f"Shunchaki link yuboring! 🚀",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "check_sub")
async def check_sub(callback: CallbackQuery):
    missing = await _not_subscribed_channels(callback.bot, callback.from_user.id)
    if missing:
        await callback.answer("❌ Hali a'zo bo'lmadingiz!", show_alert=True)
    else:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer("✅ Rahmat! Endi link yuboring! 🚀")


@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(
        "❓ <b>Yordam</b>\n\n"
        "Instagram yoki YouTube havolasini yuboring.\n"
        "Akkaunt ochiq (public) bo'lishi kerak.\n"
        "Maksimal fayl: 50 MB.",
        parse_mode="HTML",
    )


@router.message()
async def unknown(message: Message):
    text = message.text or ""
    if text.startswith("http"):
        await message.answer(
            "❌ Bu havola ishlamaydi.\n"
            "Faqat Instagram va YouTube havolalari qabul qilinadi."
        )
    else:
        await message.answer("📎 Instagram yoki YouTube linkini yuboring!")
