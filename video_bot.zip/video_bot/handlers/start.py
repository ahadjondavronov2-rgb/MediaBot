from aiogram import Router, F
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery

from middlewares.subscription import _not_subscribed_channels
from keyboards.user_kb import subscription_kb

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer(
        f"👋 Salom, <b>{message.from_user.first_name}</b>!\n\n"
        "🤖 Men <b>Video Downloader Bot</b>man.\n\n"
        "📌 <b>Nima qila olaman:</b>\n"
        "• <b>Instagram</b> — link yuboring → 720p avtomatik yuklanadi\n"
        "  └ Keyin 1080p / 4K / 🎵 Qo'shiq topish tugmalari chiqadi\n"
        "• <b>YouTube</b> — link yuboring → 720p / 1080p / 4K / 🎵 tugmalar chiqadi\n\n"
        "📎 Shunchaki link yuboring, qolgʻanini men qilaman! 🚀",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "check_sub")
async def check_subscription(callback: CallbackQuery):
    missing = await _not_subscribed_channels(callback.bot, callback.from_user.id)
    if missing:
        await callback.answer("❌ Hali barcha kanallarga a'zo bo'lmadingiz!", show_alert=True)
    else:
        await callback.message.delete()
        await callback.message.answer(
            "✅ <b>Rahmat!</b> Endi botdan to'liq foydalanishingiz mumkin.\n"
            "Link yuboring! 🚀",
            parse_mode="HTML",
        )


@router.message()
async def unknown_message(message: Message):
    text = message.text or ""
    if not text.startswith("http"):
        await message.answer(
            "📎 Instagram yoki YouTube videosi havolasini yuboring.\n\n"
            "Misol:\n"
            "• https://www.instagram.com/reel/...\n"
            "• https://www.youtube.com/watch?v=..."
        )
