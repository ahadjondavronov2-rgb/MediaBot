from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from middlewares.subscription import _not_subscribed_channels

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    name = message.from_user.first_name or "Do'st"
    text = (
        f"👋 Assalomu alaykum, <b>{name}</b>!\n\n"
        f"🤖 <b>MediaVault Bot</b> — video yuklovchi botingiz!\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"📌 <b>Nima qila olaman:</b>\n\n"
        f"📸 <b>Instagram</b>\n"
        f"   ➤ Link yuboring → 720p yuklanadi\n"
        f"   ➤ 1080p / 4K / 🎵 tugmalar chiqadi\n\n"
        f"▶️ <b>YouTube</b>\n"
        f"   ➤ Video, Shorts, Playlist — barchasi\n"
        f"   ➤ 720p / 1080p / 4K / 🎵 tanlang\n\n"
        f"🎵 <b>Qo'shiq topish</b>\n"
        f"   ➤ Har qanday videodagi musiqani toping\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"📎 <b>Ishlatish:</b> Shunchaki link yuboring!\n\n"
        f"💡 <i>Maslahat: /help — yordam</i>"
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📞 Yordam", callback_data="help_info")],
    ])
    await message.answer(text, parse_mode="HTML", reply_markup=kb)


@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(
        "❓ <b>Yordam</b>\n\n"
        "<b>Instagram:</b>\n"
        "• Reel, Post, Story havolasini yuboring\n"
        "• Akkaunt <b>ochiq (public)</b> bo'lishi kerak\n\n"
        "<b>YouTube:</b>\n"
        "• Video, Shorts, Live havolasini yuboring\n"
        "• Playlist dan bitta video ham bo'ladi\n\n"
        "<b>Cheklovlar:</b>\n"
        "• Maksimal fayl hajmi: 50 MB\n"
        "• Katta videolar uchun pastroq sifat tanlang\n\n"
        "<b>Muammo bo'lsa:</b>\n"
        "• Linkni to'g'ri nusxalang\n"
        "• Akkaunt ochiq bo'lishi kerak",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "help_info")
async def cb_help(callback: CallbackQuery):
    await callback.message.answer(
        "📎 <b>Instagram yoki YouTube</b> havolasini yuboring!\n\n"
        "Misol:\n"
        "• <code>https://www.instagram.com/reel/...</code>\n"
        "• <code>https://www.youtube.com/watch?v=...</code>\n"
        "• <code>https://youtube.com/shorts/...</code>",
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "check_sub")
async def check_subscription(callback: CallbackQuery):
    missing = await _not_subscribed_channels(callback.bot, callback.from_user.id)
    if missing:
        await callback.answer("❌ Hali barcha kanallarga a'zo bo'lmadingiz!", show_alert=True)
    else:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(
            "✅ <b>Rahmat!</b> Endi botdan to'liq foydalanishingiz mumkin!\n\n"
            "📎 Link yuboring — yuklab beraman! 🚀",
            parse_mode="HTML",
        )


@router.message()
async def unknown_handler(message: Message):
    text = message.text or ""
    if text.startswith("http"):
        await message.answer(
            "❌ Bu havola qo'llab-quvvatlanmaydi.\n\n"
            "✅ <b>Ishlaydiganlari:</b>\n"
            "• instagram.com/reel/...\n"
            "• instagram.com/p/...\n"
            "• youtube.com/watch?v=...\n"
            "• youtube.com/shorts/...\n"
            "• youtu.be/...",
            parse_mode="HTML",
        )
    else:
        await message.answer(
            "📎 <b>Link yuboring!</b>\n\n"
            "Instagram yoki YouTube havolasini yuboring.\n"
            "/help — ko'proq ma'lumot",
            parse_mode="HTML",
        )
