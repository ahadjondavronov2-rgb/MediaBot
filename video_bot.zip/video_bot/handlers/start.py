from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery

from middlewares.subscription import _not_subscribed_channels
from keyboards.user_kb import subscription_kb

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer(
        f"👋 Salom, <b>{message.from_user.first_name}</b>!\n\n"
        "🤖 Men <b>MediaVault Bot</b>man.\n\n"
        "📌 <b>Nima qila olaman:</b>\n\n"
        "📸 <b>Instagram:</b>\n"
        "  → Link yuboring — 720p avtomatik yuklanadi\n"
        "  → Keyin 1080p / 4K / 🎵 tugmalar chiqadi\n\n"
        "▶️ <b>YouTube:</b>\n"
        "  → Link yuboring — sifat tanlaysiz\n"
        "  → 720p / 1080p / 4K / 🎵 tugmalar\n\n"
        "📎 Shunchaki link yuboring! 🚀",
        parse_mode="HTML",
    )


@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(
        "❓ <b>Yordam</b>\n\n"
        "• Instagram yoki YouTube havolasini yuboring\n"
        "• Bot avtomatik ishlaydi\n\n"
        "<b>Muammo bo'lsa:</b>\n"
        "• Link to'g'riligini tekshiring\n"
        "• Akkaunt ochiq (public) bo'lishi kerak\n"
        "• 45 MB dan katta videolar yuklanmaydi",
        parse_mode="HTML",
    )


@router.callback_query(F.data == "check_sub")
async def check_subscription(callback: CallbackQuery):
    missing = await _not_subscribed_channels(callback.bot, callback.from_user.id)
    if missing:
        await callback.answer(
            "❌ Hali barcha kanallarga a'zo bo'lmadingiz!",
            show_alert=True,
        )
    else:
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(
            "✅ <b>Rahmat!</b> Endi botdan to'liq foydalanishingiz mumkin.\n\n"
            "📎 Instagram yoki YouTube linki yuboring! 🚀",
            parse_mode="HTML",
        )


@router.message()
async def unknown_handler(message: Message):
    """Noto'g'ri xabar yuborganda ko'rsatiladi."""
    text = message.text or ""
    # Agar http bilan boshlansa lekin Instagram/YouTube emas
    if text.startswith("http"):
        await message.answer(
            "❌ Bu havola qo'llab-quvvatlanmaydi.\n\n"
            "✅ <b>Qo'llab-quvvatlanadigan:</b>\n"
            "• instagram.com/reel/...\n"
            "• instagram.com/p/...\n"
            "• youtube.com/watch?v=...\n"
            "• youtu.be/...",
            parse_mode="HTML",
        )
    else:
        await message.answer(
            "📎 Instagram yoki YouTube havolasini yuboring.\n\n"
            "Misol:\n"
            "• https://www.instagram.com/reel/...\n"
            "• https://www.youtube.com/watch?v=..."
        )
