import os

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, FSInputFile

from database import save_url, get_url, add_download
from utils.downloader import download_video, cleanup
from utils.music_finder import find_music
from keyboards.user_kb import instagram_extra_kb

router = Router()

# ── Helper ────────────────────────────────────────────────────────────────────

def _is_instagram(text: str) -> bool:
    return "instagram.com" in text or "instagr.am" in text


async def _send_video(target, filepath: str, caption: str, reply_markup=None):
    video = FSInputFile(filepath)
    await target.answer_video(
        video=video,
        caption=caption,
        reply_markup=reply_markup,
        supports_streaming=True,
    )


async def _download_and_send(
    event,
    url: str,
    quality: str,
    platform: str,
    caption_suffix: str,
    reply_markup=None,
    status_msg=None,
):
    """Generic download → send → cleanup helper."""
    filepath = await download_video(url, quality)

    if filepath == "TOO_LARGE":
        text = f"❌ Fayl hajmi juda katta (45 MB dan oshadi). {quality} uchun kechirasiz."
        if status_msg:
            await status_msg.edit_text(text)
        else:
            await event.answer(text)
        return

    if not filepath or not os.path.exists(filepath):
        text = f"❌ {quality} sifatda yuklab bo'lmadi. Boshqa sifatni sinab ko'ring."
        if status_msg:
            await status_msg.edit_text(text)
        else:
            await event.answer(text)
        return

    try:
        if status_msg:
            await status_msg.delete()

        # event is Message for initial, CallbackQuery.message otherwise
        target = event if isinstance(event, Message) else event.message
        await _send_video(target, filepath, caption_suffix, reply_markup)
        user_id = event.from_user.id if isinstance(event, Message) else event.from_user.id
        await add_download(user_id, platform, quality)
    finally:
        cleanup(filepath)


# ── Initial Instagram message handler ────────────────────────────────────────

@router.message(lambda m: bool(m.text and _is_instagram(m.text)))
async def instagram_handler(message: Message):
    url = message.text.strip()
    status = await message.answer("⏳ Instagram video yuklanmoqda... (720p)")

    filepath = await download_video(url, "720")

    if filepath == "TOO_LARGE":
        await status.edit_text("❌ Video hajmi juda katta (45 MB+). Yuklab bo'lmadi.")
        return

    if not filepath or not os.path.exists(filepath):
        await status.edit_text(
            "❌ Video yuklab bo'lmadi.\n"
            "• Link to'g'riligini tekshiring\n"
            "• Akkaunt ochiq (public) bo'lishi kerak"
        )
        return

    try:
        url_id = await save_url(url)
        kb = instagram_extra_kb(url_id)
        await status.delete()

        await _send_video(
            message,
            filepath,
            "✅ <b>720p</b> | Instagram\n\n"
            "⬇️ Yuqoriroq sifat yoki qo'shiq topish uchun tugmani bosing:",
            reply_markup=kb,
        )
        await add_download(message.from_user.id, "instagram", "720")
    finally:
        cleanup(filepath)


# ── 1080p button ──────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ig_1080:"))
async def ig_1080_handler(callback: CallbackQuery):
    url_id = int(callback.data.split(":")[1])
    url = await get_url(url_id)
    if not url:
        await callback.answer("❌ URL topilmadi!", show_alert=True)
        return

    await callback.answer("⏳ 1080p yuklanmoqda...")
    status = await callback.message.answer("⏳ 1080p yuklanmoqda, kuting...")
    await _download_and_send(callback, url, "1080", "instagram", "✅ <b>1080p</b> | Instagram", status_msg=status)


# ── 4K button ─────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("ig_4k:"))
async def ig_4k_handler(callback: CallbackQuery):
    url_id = int(callback.data.split(":")[1])
    url = await get_url(url_id)
    if not url:
        await callback.answer("❌ URL topilmadi!", show_alert=True)
        return

    await callback.answer("⏳ 4K yuklanmoqda...")
    status = await callback.message.answer(
        "⏳ 4K yuklanmoqda...\n"
        "<i>(Instagram ko'pincha 1080p maksimal bo'ladi)</i>",
        parse_mode="HTML",
    )
    await _download_and_send(callback, url, "4k", "instagram", "✅ <b>4K</b> | Instagram", status_msg=status)


# ── Music finder button ───────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("music_ig:"))
async def ig_music_handler(callback: CallbackQuery):
    url_id = int(callback.data.split(":")[1])
    url = await get_url(url_id)
    if not url:
        await callback.answer("❌ URL topilmadi!", show_alert=True)
        return

    await callback.answer("🎵 Qo'shiq aniqlanmoqda...")
    status = await callback.message.answer("🎵 Audio tahlil qilinmoqda, kuting...")

    # Download low quality just for audio recognition
    filepath = await download_video(url, "360")
    if not filepath or not os.path.exists(filepath):
        await status.edit_text("❌ Audio yuklab bo'lmadi.")
        return

    try:
        result = await find_music(filepath)
    finally:
        cleanup(filepath)

    if result:
        text = (
            "🎵 <b>Qo'shiq topildi!</b>\n\n"
            f"🎤 <b>Ijrochi:</b> {result['artist']}\n"
            f"🎵 <b>Nom:</b> {result['title']}\n"
        )
        if result.get("shazam_url"):
            text += f"\n🔗 <a href='{result['shazam_url']}'>Shazam'da ko'rish</a>"
        await status.edit_text(text, parse_mode="HTML", disable_web_page_preview=True)
    else:
        await status.edit_text(
            "❌ Qo'shiq aniqlanmadi.\n"
            "Audio sifati past yoki musiqasiz video bo'lishi mumkin."
        )
