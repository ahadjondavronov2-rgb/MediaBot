import os
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, FSInputFile, InlineKeyboardMarkup, InlineKeyboardButton
from database import save_url, get_url, add_download
from utils.downloader import download_video, cleanup
from utils.music_finder import find_music, download_mp3
from keyboards.user_kb import instagram_extra_kb
from config import DOWNLOADS_DIR

router = Router()


def _is_instagram(text: str) -> bool:
    return "instagram.com" in text or "instagr.am" in text


async def _send_video(target, filepath: str, caption: str, reply_markup=None):
    video = FSInputFile(filepath)
    await target.answer_video(
        video=video, caption=caption,
        reply_markup=reply_markup,
        supports_streaming=True,
        parse_mode="HTML",
    )


@router.message(lambda m: bool(m.text and _is_instagram(m.text)))
async def instagram_handler(message: Message):
    url = message.text.strip()
    status = await message.answer("⏳ Yuklanmoqda... <i>(720p)</i>", parse_mode="HTML")
    filepath = await download_video(url, "720")

    if filepath == "TOO_LARGE":
        await status.edit_text("❌ Fayl 50MB dan katta.")
        return
    if not filepath or not os.path.exists(filepath):
        await status.edit_text(
            "❌ <b>Yuklab bo'lmadi.</b>\n\n"
            "• Link to'g'riligini tekshiring\n"
            "• Akkaunt ochiq (public) bo'lishi kerak",
            parse_mode="HTML",
        )
        return
    try:
        url_id = await save_url(url)
        kb = instagram_extra_kb(url_id)
        try: await status.delete()
        except: pass
        await _send_video(message, filepath,
            "✅ <b>720p</b> | Instagram\n"
            "⬇️ Sifat o'zgartirish yoki 🎵 qo'shiq topish:",
            reply_markup=kb)
        await add_download(message.from_user.id, "instagram", "720")
    finally:
        cleanup(filepath)


@router.callback_query(F.data.startswith("ig_1080:"))
async def ig_1080(callback: CallbackQuery):
    url_id = int(callback.data.split(":")[1])
    url = await get_url(url_id)
    if not url:
        await callback.answer("❌ URL topilmadi!", show_alert=True)
        return
    await callback.answer("⏳ 1080p yuklanmoqda...")
    status = await callback.message.answer("⏳ <b>1080p</b> yuklanmoqda...", parse_mode="HTML")
    filepath = await download_video(url, "1080")
    if filepath == "TOO_LARGE":
        await status.edit_text("❌ Fayl katta. 720p ni sinang.")
        return
    if not filepath or not os.path.exists(filepath):
        await status.edit_text("❌ 1080p yuklab bo'lmadi.")
        return
    try:
        try: await status.delete()
        except: pass
        await _send_video(callback.message, filepath, "✅ <b>1080p</b> | Instagram")
        await add_download(callback.from_user.id, "instagram", "1080")
    finally:
        cleanup(filepath)


@router.callback_query(F.data.startswith("ig_4k:"))
async def ig_4k(callback: CallbackQuery):
    url_id = int(callback.data.split(":")[1])
    url = await get_url(url_id)
    if not url:
        await callback.answer("❌ URL topilmadi!", show_alert=True)
        return
    await callback.answer("⏳ 4K yuklanmoqda...")
    status = await callback.message.answer("⏳ <b>4K</b> yuklanmoqda...", parse_mode="HTML")
    filepath = await download_video(url, "4k")
    if filepath == "TOO_LARGE":
        await status.edit_text("❌ Fayl katta. 1080p ni sinang.")
        return
    if not filepath or not os.path.exists(filepath):
        await status.edit_text("❌ 4K yuklab bo'lmadi.")
        return
    try:
        try: await status.delete()
        except: pass
        await _send_video(callback.message, filepath, "✅ <b>4K</b> | Instagram")
        await add_download(callback.from_user.id, "instagram", "4k")
    finally:
        cleanup(filepath)


@router.callback_query(F.data.startswith("music_ig:"))
async def ig_music(callback: CallbackQuery):
    url_id = int(callback.data.split(":")[1])
    url = await get_url(url_id)
    if not url:
        await callback.answer("❌ URL topilmadi!", show_alert=True)
        return
    await callback.answer("🎵 Qo'shiq aniqlanmoqda...")
    status = await callback.message.answer("🎵 Audio tahlil qilinmoqda...")

    filepath = await download_video(url, "360")
    if not filepath or not os.path.exists(filepath):
        await status.edit_text("❌ Audio yuklab bo'lmadi.")
        return
    try:
        result = await find_music(filepath)
    finally:
        cleanup(filepath)

    if result:
        yt_id = await save_url(result["yt_query"])
        text = (
            "🎵 <b>Qo'shiq topildi!</b>\n\n"
            f"🎤 <b>Artist:</b> {result['artist']}\n"
            f"🎵 <b>Nom:</b> {result['title']}\n"
        )
        if result.get("shazam_url"):
            text += f"\n🔗 <a href='{result['shazam_url']}'>Shazam</a>"
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🎧 MP3 yuklab olish", callback_data=f"dl_mp3:{yt_id}")
        ]])
        await status.edit_text(text, parse_mode="HTML",
                               disable_web_page_preview=True, reply_markup=kb)
    else:
        await status.edit_text(
            "❌ Qo'shiq aniqlanmadi.\n"
            "<i>Audio sifati past yoki musiqasiz video.</i>",
            parse_mode="HTML",
        )


@router.callback_query(F.data.startswith("dl_mp3:"))
async def dl_mp3(callback: CallbackQuery):
    url_id = int(callback.data.split(":")[1])
    yt_query = await get_url(url_id)
    if not yt_query:
        await callback.answer("❌ Topilmadi!", show_alert=True)
        return
    await callback.answer("🎧 MP3 yuklanmoqda...")
    status = await callback.message.answer(
        "🎧 MP3 yuklanmoqda...\n<i>10-20 soniya kutilg</i>",
        parse_mode="HTML",
    )
    mp3_path = await download_mp3(yt_query, DOWNLOADS_DIR)
    if not mp3_path or not os.path.exists(mp3_path):
        await status.edit_text("❌ MP3 yuklab bo'lmadi.")
        return
    try:
        audio = FSInputFile(mp3_path)
        try: await status.delete()
        except: pass
        await callback.message.answer_audio(
            audio=audio,
            caption="🎧 <b>MP3</b> | MediaVault Bot",
            parse_mode="HTML",
        )
    finally:
        cleanup(mp3_path)
