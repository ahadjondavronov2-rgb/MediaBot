import os
import re
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, FSInputFile, InlineKeyboardMarkup, InlineKeyboardButton
from database import save_url, get_url, add_download
from utils.downloader import download_video, get_video_info, cleanup
from utils.music_finder import find_music, download_mp3
from keyboards.user_kb import youtube_quality_kb
from config import DOWNLOADS_DIR

router = Router()

QUALITY_LABELS = {"720": "720p", "1080": "1080p", "4k": "4K"}


def _is_youtube(text: str) -> bool:
    return "youtube.com" in text or "youtu.be" in text


def _clean_url(url: str) -> str:
    url = url.strip()
    for param in ['si', 'pp', 'feature']:
        url = re.sub(rf'[?&]{param}=[^&]*', '', url)
    return re.sub(r'[?&]$', '', url)


def _fmt_duration(s: int) -> str:
    if not s: return ""
    if s < 3600:
        m, sec = divmod(s, 60)
        return f"{m}:{sec:02d}"
    h, r = divmod(s, 3600)
    m, sec = divmod(r, 60)
    return f"{h}:{m:02d}:{sec:02d}"


@router.message(lambda m: bool(m.text and _is_youtube(m.text)))
async def youtube_handler(message: Message):
    raw = message.text.strip()
    url = _clean_url(raw)
    status = await message.answer("⏳ Video ma'lumotlari olinmoqda...")

    info = await get_video_info(url)
    if not info:
        await status.edit_text(
            "❌ <b>Video topilmadi.</b>\n\n"
            "• Link to'g'riligini tekshiring\n"
            "• Video ochiq bo'lishi kerak",
            parse_mode="HTML",
        )
        return

    if info.get("is_live") or info.get("live_status") in ("is_live", "is_upcoming"):
        await status.edit_text(
            "📡 <b>Bu YouTube Live stream!</b>\n\n"
            "Jonli efirni yuklab bo'lmaydi.",
            parse_mode="HTML",
        )
        return

    url_id = await save_url(url)
    kb = youtube_quality_kb(url_id)

    title    = str(info.get("title") or "Video")[:60]
    duration = int(info.get("duration") or 0)
    uploader = str(info.get("uploader") or info.get("channel") or "")
    icon = "🩳" if "shorts" in raw.lower() else "🎬"

    text = f"{icon} <b>{title}</b>\n"
    if uploader: text += f"👤 {uploader}\n"
    dur = _fmt_duration(duration)
    if dur: text += f"⏱ {dur}\n"
    text += "\n📥 <b>Sifatni tanlang:</b>"

    await status.edit_text(text, reply_markup=kb, parse_mode="HTML")


async def _yt_dl(callback: CallbackQuery, quality: str):
    url_id = int(callback.data.split(":")[1])
    url = await get_url(url_id)
    if not url:
        await callback.answer("❌ URL topilmadi!", show_alert=True)
        return
    label = QUALITY_LABELS.get(quality, quality)
    await callback.answer(f"⏳ {label} yuklanmoqda...")
    status = await callback.message.answer(
        f"⏳ <b>{label}</b> yuklanmoqda...\n<i>Biroz kuting</i>",
        parse_mode="HTML",
    )
    filepath = await download_video(url, quality)
    if filepath == "TOO_LARGE":
        await status.edit_text("❌ Fayl 50MB+ katta. Pastroq sifat tanlang.")
        return
    if not filepath or not os.path.exists(filepath):
        await status.edit_text(f"❌ {label} yuklab bo'lmadi. Boshqa sifat sinang.")
        return
    try:
        video = FSInputFile(filepath)
        try: await status.delete()
        except: pass
        await callback.message.answer_video(
            video=video,
            caption=f"✅ <b>{label}</b> | YouTube",
            supports_streaming=True,
            parse_mode="HTML",
        )
        await add_download(callback.from_user.id, "youtube", quality)
    finally:
        cleanup(filepath)


@router.callback_query(F.data.startswith("yt_720:"))
async def yt_720(callback: CallbackQuery): await _yt_dl(callback, "720")

@router.callback_query(F.data.startswith("yt_1080:"))
async def yt_1080(callback: CallbackQuery): await _yt_dl(callback, "1080")

@router.callback_query(F.data.startswith("yt_4k:"))
async def yt_4k(callback: CallbackQuery): await _yt_dl(callback, "4k")


@router.callback_query(F.data.startswith("music_yt:"))
async def yt_music(callback: CallbackQuery):
    url_id = int(callback.data.split(":")[1])
    url = await get_url(url_id)
    if not url:
        await callback.answer("❌ URL topilmadi!", show_alert=True)
        return
    await callback.answer("🎵 Qo'shiq aniqlanmoqda...")
    status = await callback.message.answer("🎵 Audio tahlil qilinmoqda...")

    filepath = await download_video(url, "360")
    if not filepath or not os.path.exists(filepath):
        await status.edit_text("❌ Audio yuklab bo'lmadi.")
        return
    try:
        result = await find_music(filepath)
    finally:
        cleanup(filepath)

    if result:
        yt_id = await save_url(result["yt_query"])
        text = (
            "🎵 <b>Qo'shiq topildi!</b>\n\n"
            f"🎤 <b>Artist:</b> {result['artist']}\n"
            f"🎵 <b>Nom:</b> {result['title']}\n"
        )
        if result.get("shazam_url"):
            text += f"\n🔗 <a href='{result['shazam_url']}'>Shazam</a>"
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🎧 MP3 yuklab olish", callback_data=f"dl_mp3:{yt_id}")
        ]])
        await status.edit_text(text, parse_mode="HTML",
                               disable_web_page_preview=True, reply_markup=kb)
    else:
        await status.edit_text(
            "❌ Qo'shiq aniqlanmadi.\n"
            "<i>Audio sifati past yoki musiqasiz video.</i>",
            parse_mode="HTML",
        )
