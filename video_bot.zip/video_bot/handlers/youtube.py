import os

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, FSInputFile

from database import save_url, get_url, add_download
from utils.downloader import download_video, get_video_info, cleanup
from utils.music_finder import find_music
from keyboards.user_kb import youtube_quality_kb

router = Router()

QUALITY_LABELS = {"720": "720p", "1080": "1080p", "4k": "4K"}


def _is_youtube(text: str) -> bool:
    return "youtube.com" in text or "youtu.be" in text


# ── Initial YouTube message handler ──────────────────────────────────────────

@router.message(lambda m: bool(m.text and _is_youtube(m.text)))
async def youtube_handler(message: Message):
    url = message.text.strip()
    status = await message.answer("⏳ Video ma'lumotlari olinmoqda...")

    info = await get_video_info(url)
    if not info:
        await status.edit_text(
            "❌ Video ma'lumotlarini olish imkoni bo'lmadi.\n"
            "• Link to'g'riligini tekshiring\n"
            "• Video ochiq (public) bo'lishi kerak"
        )
        return

    url_id = await save_url(url)
    kb = youtube_quality_kb(url_id)

    title = (info.get("title") or "Video")[:60]
    duration = info.get("duration") or 0
    mins, secs = divmod(int(duration), 60)
    uploader = info.get("uploader") or info.get("channel") or ""

    await status.edit_text(
        f"🎬 <b>{title}</b>\n"
        f"👤 {uploader}\n"
        f"⏱ {mins}:{secs:02d}\n\n"
        f"📥 <b>Sifatni tanlang:</b>",
        reply_markup=kb,
        parse_mode="HTML",
    )


# ── Quality download callbacks ────────────────────────────────────────────────

async def _yt_download(callback: CallbackQuery, quality: str):
    url_id = int(callback.data.split(":")[1])
    url = await get_url(url_id)
    if not url:
        await callback.answer("❌ URL topilmadi!", show_alert=True)
        return

    label = QUALITY_LABELS.get(quality, quality)
    await callback.answer(f"⏳ {label} yuklanmoqda...")
    status = await callback.message.answer(
        f"⏳ <b>{label}</b> yuklanmoqda, kuting...\n"
        "<i>(Katta videolar biroz vaqt olishi mumkin)</i>",
        parse_mode="HTML",
    )

    filepath = await download_video(url, quality)

    if filepath == "TOO_LARGE":
        await status.edit_text(
            f"❌ Fayl hajmi juda katta (45 MB+).\n"
            f"Pastroq sifatni sinab ko'ring."
        )
        return

    if not filepath or not os.path.exists(filepath):
        await status.edit_text(
            f"❌ {label} sifat mavjud emas yoki yuklab bo'lmadi.\n"
            "Boshqa sifatni tanlang."
        )
        return

    try:
        video = FSInputFile(filepath)
        await status.delete()
        await callback.message.answer_video(
            video=video,
            caption=f"✅ <b>{label}</b> | YouTube",
            supports_streaming=True,
            parse_mode="HTML",
        )
        await add_download(callback.from_user.id, "youtube", quality)
    finally:
        cleanup(filepath)


@router.callback_query(F.data.startswith("yt_720:"))
async def yt_720(callback: CallbackQuery):
    await _yt_download(callback, "720")


@router.callback_query(F.data.startswith("yt_1080:"))
async def yt_1080(callback: CallbackQuery):
    await _yt_download(callback, "1080")


@router.callback_query(F.data.startswith("yt_4k:"))
async def yt_4k(callback: CallbackQuery):
    await _yt_download(callback, "4k")


# ── Music finder button ───────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("music_yt:"))
async def yt_music_handler(callback: CallbackQuery):
    url_id = int(callback.data.split(":")[1])
    url = await get_url(url_id)
    if not url:
        await callback.answer("❌ URL topilmadi!", show_alert=True)
        return

    await callback.answer("🎵 Qo'shiq aniqlanmoqda...")
    status = await callback.message.answer("🎵 Audio tahlil qilinmoqda, kuting...")

    filepath = await download_video(url, "360")
    if not filepath or not os.path.exists(filepath):
        await status.edit_text("❌ Audio yuklab bo'lmadi.")
        return

    try:
        result = await find_music(filepath)
    finally:
        cleanup(filepath)

    if result:
        text = (
            "🎵 <b>Qo'shiq topildi!</b>\n\n"
            f"🎤 <b>Ijrochi:</b> {result['artist']}\n"
            f"🎵 <b>Nom:</b> {result['title']}\n"
        )
        if result.get("shazam_url"):
            text += f"\n🔗 <a href='{result['shazam_url']}'>Shazam'da ko'rish</a>"
        await status.edit_text(text, parse_mode="HTML", disable_web_page_preview=True)
    else:
        await status.edit_text(
            "❌ Qo'shiq aniqlanmadi.\n"
            "Audio sifati past yoki musiqasiz video bo'lishi mumkin."
        )
