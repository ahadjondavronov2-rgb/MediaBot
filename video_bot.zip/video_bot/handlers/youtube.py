import os
import re
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, FSInputFile

from database import save_url, get_url, add_download
from utils.downloader import download_video, get_video_info, cleanup
from utils.music_finder import find_music
from keyboards.user_kb import youtube_quality_kb

router = Router()

QUALITY_LABELS = {"720": "720p", "1080": "1080p", "4k": "4K"}


def _is_youtube(text: str) -> bool:
    return "youtube.com" in text or "youtu.be" in text


def _clean_url(url: str) -> str:
    """?si= va boshqa tracking parametrlarni olib tashlash"""
    # Shorts URL ni standart formatga o'tkazish
    url = url.strip()
    # si= parametrini olib tashlash
    url = re.sub(r'[?&]si=[^&]*', '', url)
    # pp= parametrini olib tashlash
    url = re.sub(r'[?&]pp=[^&]*', '', url)
    # Oxirida qolgan ? yoki & ni tozalash
    url = re.sub(r'[?&]$', '', url)
    return url


def _format_duration(seconds: int) -> str:
    if not seconds:
        return ""
    if seconds < 3600:
        m, s = divmod(seconds, 60)
        return f"{m}:{s:02d}"
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}"


def _is_live(info: dict) -> bool:
    return info.get("is_live") or info.get("live_status") in ("is_live", "is_upcoming")


@router.message(lambda m: bool(m.text and _is_youtube(m.text)))
async def youtube_handler(message: Message):
    raw_url = message.text.strip()
    url = _clean_url(raw_url)

    status = await message.answer("⏳ Video ma'lumotlari olinmoqda...")

    info = await get_video_info(url)
    if not info:
        await status.edit_text(
            "❌ <b>Video topilmadi.</b>\n\n"
            "Sabablari:\n"
            "• Link noto'g'ri bo'lishi mumkin\n"
            "• Video o'chirilgan bo'lishi mumkin\n"
            "• Video yopiq (private) bo'lishi mumkin",
            parse_mode="HTML",
        )
        return

    # Live stream tekshiruvi
    if _is_live(info):
        await status.edit_text(
            "📡 <b>Bu YouTube Live stream!</b>\n\n"
            "Jonli efirni yuklab bo'lmaydi.\n"
            "Efir tugagach, yozuv sifatida yuklab olish mumkin bo'ladi.",
            parse_mode="HTML",
        )
        return

    url_id = await save_url(url)
    kb = youtube_quality_kb(url_id)

    title    = str(info.get("title") or "Video")[:60]
    duration = int(info.get("duration") or 0)
    uploader = str(info.get("uploader") or info.get("channel") or "")
    is_shorts = "shorts" in raw_url.lower()
    icon = "🩳" if is_shorts else "🎬"

    text = f"{icon} <b>{title}</b>\n"
    if uploader:
        text += f"👤 {uploader}\n"
    dur = _format_duration(duration)
    if dur:
        text += f"⏱ {dur}\n"
    text += "\n📥 <b>Sifatni tanlang:</b>"

    await status.edit_text(text, reply_markup=kb, parse_mode="HTML")


async def _yt_download(callback: CallbackQuery, quality: str):
    parts = callback.data.split(":", 1)
    if len(parts) != 2:
        await callback.answer("❌ Xatolik!", show_alert=True)
        return

    url_id = int(parts[1])
    url = await get_url(url_id)
    if not url:
        await callback.answer("❌ URL topilmadi!", show_alert=True)
        return

    label = QUALITY_LABELS.get(quality, quality)
    await callback.answer(f"⏳ {label} yuklanmoqda...")
    status = await callback.message.answer(
        f"⏳ <b>{label}</b> yuklanmoqda...\n"
        f"<i>Katta videolar biroz vaqt olishi mumkin</i>",
        parse_mode="HTML",
    )

    filepath = await download_video(url, quality)

    if filepath == "TOO_LARGE":
        await status.edit_text(
            f"❌ Video hajmi katta (50MB+).\n"
            f"Pastroq sifatni sinab ko'ring."
        )
        return
    if not filepath or not os.path.exists(filepath):
        await status.edit_text(
            f"❌ <b>{label}</b> yuklab bo'lmadi.\n"
            "Boshqa sifatni sinab ko'ring.",
            parse_mode="HTML",
        )
        return

    try:
        video = FSInputFile(filepath)
        try:
            await status.delete()
        except Exception:
            pass
        await callback.message.answer_video(
            video=video,
            caption=f"✅ <b>{label}</b> | YouTube",
            supports_streaming=True,
            parse_mode="HTML",
        )
        await add_download(callback.from_user.id, "youtube", quality)
    finally:
        cleanup(filepath)


@router.callback_query(F.data.startswith("yt_720:"))
async def yt_720(callback: CallbackQuery):
    await _yt_download(callback, "720")


@router.callback_query(F.data.startswith("yt_1080:"))
async def yt_1080(callback: CallbackQuery):
    await _yt_download(callback, "1080")


@router.callback_query(F.data.startswith("yt_4k:"))
async def yt_4k(callback: CallbackQuery):
    await _yt_download(callback, "4k")


@router.callback_query(F.data.startswith("music_yt:"))
async def yt_music(callback: CallbackQuery):
    parts = callback.data.split(":", 1)
    if len(parts) != 2:
        await callback.answer("❌ Xatolik!", show_alert=True)
        return
    url_id = int(parts[1])
    url = await get_url(url_id)
    if not url:
        await callback.answer("❌ URL topilmadi!", show_alert=True)
        return

    await callback.answer("🎵 Qo'shiq aniqlanmoqda...")
    status = await callback.message.answer("🎵 Audio tahlil qilinmoqda, kuting...")

    filepath = await download_video(url, "360")
    if not filepath or not os.path.exists(filepath):
        await status.edit_text("❌ Audio yuklab bo'lmadi.")
        return

    try:
        result = await find_music(filepath)
    finally:
        cleanup(filepath)

    if result:
        text = (
            "🎵 <b>Qo'shiq topildi!</b>\n\n"
            f"🎤 <b>Ijrochi:</b> {result['artist']}\n"
            f"🎵 <b>Nom:</b> {result['title']}\n"
        )
        if result.get("shazam_url"):
            text += f"\n🔗 <a href='{result['shazam_url']}'>Qo'shiqni topish</a>"
        await status.edit_text(text, parse_mode="HTML", disable_web_page_preview=True)
    else:
        await status.edit_text(
            "❌ Qo'shiq aniqlanmadi.\n"
            "<i>Sabablar: audio sifati past yoki musiqasiz video</i>",
            parse_mode="HTML",
        )
