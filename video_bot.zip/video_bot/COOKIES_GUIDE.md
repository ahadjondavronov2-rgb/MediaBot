# YouTube Cookies qo'llash qo'llanmasi

## Nima uchun kerak?

YouTube Render kabi cloud serverlarini "bot" deb bloklaydi.
Cookies fayli orqali yt-dlp "haqiqiy foydalanuvchi" sifatida ishlaydi.

---

## 1-QADAM: Cookies faylini olish (PC brauzeri kerak)

### Chrome uchun:
1. Chrome da **youtube.com** ga kiring
2. Google akkauntingizga **kiring** (login bo'ling)
3. Chrome Web Store dan **"Get cookies.txt LOCALLY"** extensionni o'rnating
   → https://chrome.google.com/webstore/detail/get-cookiestxt-locally/cclelndahbckbenkjhflpdbgdldlbecc
4. youtube.com sahifasida turgan holda extension ikonkasini bosing
5. **"Export"** tugmasini bosing
6. Fayl `youtube.com_cookies.txt` nomi bilan yuklab olinadi
7. Fayl nomini **`yt_cookies.txt`** ga o'zgartiring

### Firefox uchun:
1. Firefox da youtube.com ga kiring va login bo'ling
2. **"cookies.txt"** extensionini o'rnating
3. Extension → Export → `yt_cookies.txt` nomi bilan saqlang

---

## 2-QADAM: Render ga yuklash

1. **render.com** ga kiring
2. Botingizning **Dashboard** ini oching
3. Chap menuda **"Environment"** ni bosing
4. Pastga aylantiring → **"Secret Files"** bo'limini toping
5. **"Add Secret File"** tugmasini bosing
6. **Filename** maydoniga yozing: `/etc/secrets/yt_cookies.txt`
7. **File Contents** maydoniga `yt_cookies.txt` faylining **barcha mazmunini** nusxa ko'chiring va joylashtiring
8. **"Save Changes"** tugmasini bosing
9. Render avtomatik **redeploy** qiladi — biroz kuting

---

## 3-QADAM: Tekshirish

Bot qayta ishga tushgandan so'ng:
- Render Logs da `[downloader] 1-qatlam: Cookies bilan urinish...` va `✅ Cookies ishladi!` ko'rinsa — hammasi zo'r!
- Agar `⚠️ Cookies ishlamadi → 2-qatlam: Invidious` ko'rinsa — cookie eskirgan, yangilash kerak

---

## Muhim eslatmalar

- Cookie fayli **2-4 haftada eskirishi** mumkin — shu vaqtdan so'ng bot avtomatik **Invidious** ga o'tadi (siz hech narsa qilmasangiz ham ishlayveradi)
- Cookie yangilash uchun faqat 2-QADAMni qaytaring (yangi export qilib, Render da almashtiring)
- Cookie faylingizni hech kimga bermang — bu sizning YouTube akkauntingizga kirish imkoniyati

---

## Bot qanday ishlaydi (3 qatlam)

```
YouTube URL keldi
      ↓
Cookies fayl bor? → HA → YouTube dan to'g'ridan yuklab oladi ✅
      ↓ (YO'Q yoki xato)
Invidious orqali yuklab oladi ✅
      ↓ (Invidious ham xato)
MP3 uchun: ytsearch fallback ✅
```

Bot HECH QACHON ishlamay qolmaydi.
