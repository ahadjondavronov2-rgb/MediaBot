from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def admin_main_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📊 Statistika",            callback_data="adm_stats")],
            [InlineKeyboardButton(text="📢 Kanal/Guruh boshqaruv", callback_data="adm_channels")],
            [InlineKeyboardButton(text="📣 Broadcast",             callback_data="adm_broadcast")],
            [InlineKeyboardButton(text="🚫 Ban / ✅ Unban",        callback_data="adm_ban_menu")],
        ]
    )


def admin_channels_kb(channels: list) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=f"❌ {ch[2]}", callback_data=f"del_ch:{ch[1]}")]
        for ch in channels
    ]
    rows.append([InlineKeyboardButton(text="➕ Yangi kanal/guruh qo'shish", callback_data="add_ch")])
    rows.append([InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_ban_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🚫 Ban qilish",   callback_data="do_ban")],
            [InlineKeyboardButton(text="✅ Unban qilish",  callback_data="do_unban")],
            [InlineKeyboardButton(text="🔙 Orqaga",        callback_data="adm_back")],
        ]
    )


def back_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="🔙 Orqaga", callback_data="adm_back")]]
    )
