from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def instagram_extra_kb(url_id: int) -> InlineKeyboardMarkup:
    """
    Shown AFTER auto 720p Instagram download.
    Lets user pick higher quality or find the song.
    """
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="📹 1080p", callback_data=f"ig_1080:{url_id}"),
                InlineKeyboardButton(text="🎬 4K",    callback_data=f"ig_4k:{url_id}"),
            ],
            [
                InlineKeyboardButton(text="🎵 Qo'shiq topish", callback_data=f"music_ig:{url_id}"),
            ],
        ]
    )


def youtube_quality_kb(url_id: int) -> InlineKeyboardMarkup:
    """
    Shown BEFORE download for YouTube — user picks quality first.
    """
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="📱 720p",  callback_data=f"yt_720:{url_id}"),
                InlineKeyboardButton(text="📹 1080p", callback_data=f"yt_1080:{url_id}"),
                InlineKeyboardButton(text="🎬 4K",    callback_data=f"yt_4k:{url_id}"),
            ],
            [
                InlineKeyboardButton(text="🎵 Qo'shiq topish", callback_data=f"music_yt:{url_id}"),
            ],
        ]
    )


def subscription_kb(channels: list) -> InlineKeyboardMarkup:
    buttons = [
        [InlineKeyboardButton(text=f"📢 {ch[2]}", url=ch[3])]
        for ch in channels
    ]
    buttons.append(
        [InlineKeyboardButton(text="✅ A'zo bo'ldim, tekshirish", callback_data="check_sub")]
    )
    return InlineKeyboardMarkup(inline_keyboard=buttons)
