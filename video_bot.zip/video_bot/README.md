# 🎬 Video Downloader Bot

Instagram va YouTube videolarini yuklash, qo'shiq topish imkoniyatli Telegram bot.

---

## 📁 Fayl strukturasi

```
video_bot/
├── main.py               ← Asosiy ishga tushirish fayli
├── config.py             ← Sozlamalar
├── database.py           ← Ma'lumotlar bazasi (SQLite)
├── requirements.txt      ← Python kutubxonalari
├── .env                  ← Maxfiy ma'lumotlar (o'zingiz yaratasiz)
├── handlers/
│   ├── start.py          ← /start va a'zolik tekshiruvi
│   ├── instagram.py      ← Instagram yuklab olish
│   ├── youtube.py        ← YouTube yuklab olish
│   └── admin.py          ← Admin panel
├── keyboards/
│   ├── user_kb.py        ← Foydalanuvchi tugmalari
│   └── admin_kb.py       ← Admin tugmalari
├── middlewares/
│   └── subscription.py   ← Majburiy a'zolik tekshiruvi
└── utils/
    ├── downloader.py      ← yt-dlp bilan yuklab olish
    └── music_finder.py   ← Shazam orqali qo'shiq topish
```

---

## ⚙️ O'rnatish

### 1. Kerakli dasturlar
```bash
# Python 3.11+
python --version

# ffmpeg (majburiy — audio tahlil uchun)
sudo apt install ffmpeg        # Linux
brew install ffmpeg            # macOS
# Windows: https://ffmpeg.org/download.html
```

### 2. Kutubxonalarni o'rnatish
```bash
pip install -r requirements.txt
```

### 3. `.env` fayl yaratish
```bash
cp .env.example .env
```
`.env` faylini oching va to'ldiring:
```
BOT_TOKEN=7xxxxxxxxxx:AAxxxxxxxxxxxxxxxxxxxxxxxx
ADMIN_IDS=123456789
```

- **BOT_TOKEN** — @BotFather dan olgan token
- **ADMIN_IDS** — O'zingizning Telegram ID (bir nechta bo'lsa vergul bilan: `111,222`)

### 4. Botni ishga tushirish
```bash
python main.py
```

---

## 🤖 Bot ishlash tartibi

### Instagram
1. Foydalanuvchi Instagram havolasini yuboradi
2. Bot **720p** da avtomatik yuklab yuboradi
3. Quyida tugmalar paydo bo'ladi:
   - 📹 **1080p** — yuqori sifatda qayta yuklaydi
   - 🎬 **4K** — eng yuqori sifat (mavjud bo'lsa)
   - 🎵 **Qo'shiq topish** — Shazam orqali qo'shiqni topadi

### YouTube
1. Foydalanuvchi YouTube havolasini yuboradi
2. Video ma'lumotlari + **sifat tanlash tugmalari** chiqadi:
   - 📱 720p / 📹 1080p / 🎬 4K
   - 🎵 Qo'shiq topish
3. Foydalanuvchi tanlagan sifatda yuklanadi

### Admin panel (/admin)
- 📊 Statistika — foydalanuvchilar, yuklab olinganlar soni
- 📢 Kanal/Guruh — majburiy a'zolik kanallarini boshqarish
- 📣 Broadcast — barcha foydalanuvchilarga xabar yuborish
- 🚫 Ban / ✅ Unban — foydalanuvchilarni bloklash/ochish

---

## ⚠️ Muhim eslatmalar

- **Fayl hajmi limiti:** Telegram botlar 50 MB gacha fayl yuborishi mumkin. Katta videolar yuklanmaydi.
- **Instagram:** Faqat **ochiq (public)** akkauntlar ishlaydi.
- **ffmpeg** o'rnatilmasa, qo'shiq topish ishlamaydi.
- Bot kanal adminligi bo'lmasa, majburiy a'zolik tekshiruvi ishlamaydi.

---

## 🛠 Texnologiyalar

| Kutubxona | Maqsad |
|-----------|--------|
| `aiogram 3` | Telegram Bot Framework |
| `yt-dlp` | Video yuklab olish (Instagram + YouTube) |
| `shazamio` | Qo'shiq aniqlash |
| `aiosqlite` | Asinxron SQLite ma'lumotlar bazasi |
| `ffmpeg` | Audio ajratish |
