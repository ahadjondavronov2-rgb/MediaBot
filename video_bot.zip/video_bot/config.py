import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
ADMIN_IDS: list[int] = [
    int(i) for i in os.getenv("ADMIN_IDS", "").split(",") if i.strip().isdigit()
]
DATABASE_PATH: str = "bot.db"
DOWNLOADS_DIR: str = "downloads"
MAX_FILE_SIZE_MB: int = 50

IG_SESSION_ID: str = os.getenv("IG_SESSION_ID", "")

# YouTube cookies fayli yo'li.
# Render da: Environment → Secret Files → /etc/secrets/yt_cookies.txt
# Lokal test uchun: loyiha papkasida yt_cookies.txt fayli
YT_COOKIES_FILE: str = os.getenv(
    "YT_COOKIES_FILE",
    "/etc/secrets/yt_cookies.txt"   # Render Secret Files standart yo'li
)
