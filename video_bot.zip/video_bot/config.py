import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
ADMIN_IDS: list[int] = [
    int(i) for i in os.getenv("ADMIN_IDS", "").split(",") if i.strip().isdigit()
]
DATABASE_PATH: str = "bot.db"
DOWNLOADS_DIR: str = "downloads"
MAX_FILE_SIZE_MB: int = 50  # Telegram bots max ~50MB, we leave margin
