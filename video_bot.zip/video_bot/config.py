import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
ADMIN_IDS: list[int] = [
    int(i) for i in os.getenv("ADMIN_IDS", "").split(",") if i.strip().isdigit()
]
DATABASE_PATH: str = "bot.db"
DOWNLOADS_DIR: str = "downloads"
MAX_FILE_SIZE_MB: int = 50

# Instagram sessionid
IG_SESSION_ID: str = os.getenv("IG_SESSION_ID", "")

# YouTube — 3 xil usulni qo'llab-quvvatlaydi
YT_SESSION_ID: str = os.getenv("YT_SESSION_ID", "")
YT_COOKIES: str = os.getenv("YT_COOKIES", "")

# Render Secret File — eng ishonchli usul
YT_COOKIES_FILE: str = "/etc/secrets/yt_cookies.txt"
