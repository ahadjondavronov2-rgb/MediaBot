import asyncio
import logging
import os
import glob
import base64

# ── 1. Node.js PATH ga qo'shish ───────────────────────────────────────────────
_NODE_DIRS = [
    "/opt/render/project/src/.nodeenv/bin",   # nodeenv (build da o'rnatiladi)
    "/tmp/node/bin",                           # fallback
]
for _nd in _NODE_DIRS:
    if os.path.exists(_nd):
        os.environ["PATH"] = _nd + ":" + os.environ.get("PATH", "")
        print(f"✅ Node.js: {_nd}")
        break
else:
    print("⚠️ Node.js topilmadi — YouTube cheklangan ishlashi mumkin")

# ── 2. ffmpeg ─────────────────────────────────────────────────────────────────
import static_ffmpeg
static_ffmpeg.add_paths()

from aiohttp import web
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage

from config import BOT_TOKEN
from database import init_db
from middlewares.subscription import SubscriptionMiddleware
from handlers import start, instagram, youtube, admin

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


# ── Web server (Render port uchun) ────────────────────────────────────────────
async def health_check(request):
    return web.Response(text="✅ MediaVault Bot ishlayapti!")


async def start_web_server():
    app = web.Application()
    app.router.add_get("/", health_check)
    runner = web.AppRunner(app)
    await runner.setup()
    port = int(os.getenv("PORT", 10000))
    site = web.TCPSite(runner, "0.0.0.0", port)
    await site.start()
    logger.info(f"🌐 Web server port {port}")
    return runner


# ── Asosiy bot ────────────────────────────────────────────────────────────────
async def main():
    if not BOT_TOKEN:
        logger.error("❌ BOT_TOKEN topilmadi! Render Environment ga qo'shing.")
        return

    os.makedirs("downloads", exist_ok=True)

    # Web server BIRINCHI ishga tushsin — Render port topsin
    web_runner = await start_web_server()

    await init_db()
    logger.info("✅ Database tayyor")

    bot = Bot(token=BOT_TOKEN)
    dp  = Dispatcher(storage=MemoryStorage())

    dp.message.middleware(SubscriptionMiddleware())
    dp.callback_query.middleware(SubscriptionMiddleware())

    dp.include_router(admin.router)
    dp.include_router(instagram.router)
    dp.include_router(youtube.router)
    dp.include_router(start.router)

    logger.info("🚀 Bot ishga tushdi!")
    await bot.delete_webhook(drop_pending_updates=True)

    try:
        await dp.start_polling(bot)
    except Exception as e:
        logger.error(f"❌ Bot xatosi: {e}")
    finally:
        await web_runner.cleanup()
        await bot.session.close()
        logger.info("🛑 Bot to'xtatildi.")


if __name__ == "__main__":
    asyncio.run(main())
