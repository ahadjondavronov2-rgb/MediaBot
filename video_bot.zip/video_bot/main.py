import asyncio
import logging
import os
import glob

# Node.js PATH ga qo'shish — /tmp da izlaymiz
node_dirs = glob.glob("/tmp/node-*/bin")
if node_dirs:
    os.environ["PATH"] = node_dirs[0] + ":" + os.environ.get("PATH", "")
    print(f"✅ Node.js topildi: {node_dirs[0]}")
else:
    print("⚠️ Node.js topilmadi")

import static_ffmpeg
static_ffmpeg.add_paths()

from aiohttp import web
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage

from config import BOT_TOKEN
from database import init_db
from middlewares.subscription import SubscriptionMiddleware
from handlers import start, instagram, youtube, admin

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


async def health_check(request):
    return web.Response(text="✅ MediaVault Bot ishlayapti!")


async def start_web_server():
    app = web.Application()
    app.router.add_get("/", health_check)
    runner = web.AppRunner(app)
    await runner.setup()
    port = int(os.getenv("PORT", 10000))
    site = web.TCPSite(runner, "0.0.0.0", port)
    await site.start()
    logger.info(f"🌐 Web server port {port}")
    return runner


async def main():
    if not BOT_TOKEN:
        raise ValueError("❌ BOT_TOKEN topilmadi!")

    os.makedirs("downloads", exist_ok=True)
    await init_db()
    logger.info("✅ Database tayyor")

    bot = Bot(token=BOT_TOKEN)
    dp  = Dispatcher(storage=MemoryStorage())

    dp.message.middleware(SubscriptionMiddleware())
    dp.callback_query.middleware(SubscriptionMiddleware())

    dp.include_router(admin.router)
    dp.include_router(instagram.router)
    dp.include_router(youtube.router)
    dp.include_router(start.router)

    web_runner = await start_web_server()
    logger.info("🚀 Bot ishga tushdi!")
    await bot.delete_webhook(drop_pending_updates=True)

    try:
        await dp.start_polling(bot)
    finally:
        await web_runner.cleanup()
        await bot.session.close()
