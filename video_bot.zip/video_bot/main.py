import asyncio
import logging
import os

from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage

from config import BOT_TOKEN
from database import init_db
from middlewares.subscription import SubscriptionMiddleware
from handlers import start, instagram, youtube, admin

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


async def main():
    if not BOT_TOKEN:
        raise ValueError("BOT_TOKEN .env faylida topilmadi!")

    os.makedirs("downloads", exist_ok=True)
    await init_db()
    logger.info("✅ Database tayyor")

    bot = Bot(token=BOT_TOKEN)
    dp  = Dispatcher(storage=MemoryStorage())

    # ── Middlewares (admin handler bundan ozod — config.py orqali) ──
    dp.message.middleware(SubscriptionMiddleware())
    dp.callback_query.middleware(SubscriptionMiddleware())

    # ── Routers (admin birinchi — /admin komandasi boshqalarga tegmasin) ──
    dp.include_router(admin.router)
    dp.include_router(instagram.router)
    dp.include_router(youtube.router)
    dp.include_router(start.router)   # fallback — oxirida

    logger.info("🚀 Bot ishga tushdi!")
    await bot.delete_webhook(drop_pending_updates=True)

    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()
        logger.info("Bot to'xtatildi.")


if __name__ == "__main__":
    asyncio.run(main())
