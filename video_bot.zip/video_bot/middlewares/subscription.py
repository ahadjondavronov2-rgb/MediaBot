from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Message, CallbackQuery

from config import ADMIN_IDS
from database import add_user, is_banned, get_channels
from keyboards.user_kb import subscription_kb


async def _not_subscribed_channels(bot, user_id: int) -> list:
    """Return list of channels the user has NOT joined yet."""
    channels = await get_channels()
    missing = []
    for ch in channels:
        try:
            member = await bot.get_chat_member(ch[1], user_id)
            if member.status in ("left", "kicked"):
                missing.append(ch)
        except Exception:
            pass  # bot not in channel or channel not found — skip
    return missing


class SubscriptionMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user = data.get("event_from_user")
        if user is None:
            return await handler(event, data)

        # Always register the user silently
        await add_user(user.id, user.username or "", user.full_name or "")

        # Admins bypass all checks
        if user.id in ADMIN_IDS:
            return await handler(event, data)

        # Banned users
        if await is_banned(user.id):
            if isinstance(event, Message):
                await event.answer("🚫 Siz botdan bloklangansiz.")
            elif isinstance(event, CallbackQuery):
                await event.answer("🚫 Siz botdan bloklangansiz.", show_alert=True)
            return

        # Subscription gate
        missing = await _not_subscribed_channels(data["bot"], user.id)
        if missing:
            text = (
                "⚠️ <b>Botdan foydalanish uchun</b> quyidagi\n"
                "kanal/guruhlarga a'zo bo'ling:\n"
            )
            if isinstance(event, Message):
                await event.answer(text, reply_markup=subscription_kb(missing), parse_mode="HTML")
            elif isinstance(event, CallbackQuery):
                await event.answer("Avval kanallarga a'zo bo'ling!", show_alert=True)
            return

        return await handler(event, data)
