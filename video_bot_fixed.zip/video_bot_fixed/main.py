import asyncio
import logging
import os

# FAQAT aiohttp import qilinadi — boshqa hech narsa emas
# Web server 1 soniyada ishga tushishi uchun!
from aiohttp import web

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


async def health_check(request):
    return web.Response(text="✅ MediaVault Bot ishlayapti!")


async def start_web_server():
    """Render port tekshirishidan o'tish uchun — BIRINCHI ishga tushadi"""
    app = web.Application()
    app.router.add_get("/", health_check)
    runner = web.AppRunner(app)
    await runner.setup()
    port = int(os.getenv("PORT", 10000))
    site = web.TCPSite(runner, "0.0.0.0", port)
    await site.start()
    logger.info(f"🌐 Web server port {port} — Render port topdi ✅")
    return runner


async def main():
    # ── 1. WEB SERVER — birinchi, boshqa hech narsa yo'q ─────────────────────
    web_runner = await start_web_server()

    # ── 2. ffmpeg — web serverdan KEYIN (sekin yuklanadi, lekin OK) ──────────
    logger.info("📦 ffmpeg yuklanmoqda...")
    import static_ffmpeg
    static_ffmpeg.add_paths()
    logger.info("✅ ffmpeg tayyor")

    # ── 3. Qolgan barcha importlar ────────────────────────────────────────────
    from aiogram import Bot, Dispatcher
    from aiogram.fsm.storage.memory import MemoryStorage
    from config import BOT_TOKEN
    from database import init_db
    from middlewares.subscription import SubscriptionMiddleware
    from handlers import start, instagram, youtube, admin

    # ── 4. Bot tekshiruvi ─────────────────────────────────────────────────────
    if not BOT_TOKEN:
        logger.error("❌ BOT_TOKEN topilmadi! Render Environment ga qo'shing.")
        await web_runner.cleanup()
        return

    # ── 5. Database ───────────────────────────────────────────────────────────
    os.makedirs("downloads", exist_ok=True)
    await init_db()
    logger.info("✅ Database tayyor")

    # ── 6. Bot va dispatcher ──────────────────────────────────────────────────
    bot = Bot(token=BOT_TOKEN)
    dp  = Dispatcher(storage=MemoryStorage())

    dp.message.middleware(SubscriptionMiddleware())
    dp.callback_query.middleware(SubscriptionMiddleware())

    dp.include_router(admin.router)
    dp.include_router(instagram.router)
    dp.include_router(youtube.router)
    dp.include_router(start.router)

    logger.info("🚀 Bot ishga tushdi!")
    await bot.delete_webhook(drop_pending_updates=True)

    try:
        await dp.start_polling(bot)
    except Exception as e:
        logger.error(f"❌ Bot xatosi: {e}")
    finally:
        await web_runner.cleanup()
        await bot.session.close()
        logger.info("🛑 Bot to'xtatildi.")


if __name__ == "__main__":
    asyncio.run(main())
