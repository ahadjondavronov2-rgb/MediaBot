import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
ADMIN_IDS: list[int] = [
    int(i) for i in os.getenv("ADMIN_IDS", "").split(",") if i.strip().isdigit()
]
DATABASE_PATH: str = "bot.db"
DOWNLOADS_DIR: str = "downloads"
MAX_FILE_SIZE_MB: int = 50

IG_SESSION_ID: str = os.getenv("IG_SESSION_ID", "")

# Eslatma: YT_SESSION_ID, YT_COOKIES, YT_COOKIES_B64, YT_COOKIES_FILE
# o'chirildi — ular hech qayerda ishlatilmagan (dead code).
# YouTube uchun endi yt-dlp-invidious plugin Invidious orqali ishlaydi,
# YouTube cookie si umuman kerak emas.
