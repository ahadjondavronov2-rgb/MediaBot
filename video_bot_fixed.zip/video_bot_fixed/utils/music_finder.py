import asyncio
import os
import uuid
import aiohttp
import yt_dlp

from config import DOWNLOADS_DIR


# ─── Invidious qidirish ───────────────────────────────────────────────────────
#
# Muammo: eski download_mp3() "ytsearch1:Artist - Title" formatini to'g'ridan
# YouTube Search API ga yuborgandi. Render da bu ham ishlamaydi — xuddi
# video yuklab olishdagi muammo kabi (IP blok, JS runtime xatosi).
#
# Yechim: Invidious public API orqali qidiramiz → birinchi natijaning
# video ID sini olamiz → "invidious:VIDEO_ID" ga aylantiramiz.
# Bir instance ishlamasa, avtomatik keyingisiga o'tadi.

_INVIDIOUS_INSTANCES = [
    "https://inv.tux.pizza",
    "https://invidious.privacyredirect.com",
    "https://yt.artemislena.eu",
    "https://invidious.nikkosphere.com",
]


async def _invidious_search(query: str) -> str | None:
    """
    Invidious API /api/v1/search endpoint orqali qidirib, birinchi
    videoning ID sini 'invidious:VIDEO_ID' formatida qaytaradi.
    Barcha instancelar javob bermasa None qaytaradi.
    """
    params = {"q": query, "type": "video", "fields": "videoId", "page": "1"}
    async with aiohttp.ClientSession() as session:
        for instance in _INVIDIOUS_INSTANCES:
            try:
                async with session.get(
                    f"{instance}/api/v1/search",
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=8),
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data and isinstance(data, list) and len(data) > 0:
                            vid_id = data[0].get("videoId")
                            if vid_id:
                                print(f"[music] Invidious search ✅ ({instance}): {vid_id}")
                                return f"invidious:{vid_id}"
            except Exception as e:
                print(f"[music] {instance} ishlamadi: {e}")
                continue
    print("[music] WARN: barcha Invidious instancelar javob bermadi")
    return None


# ─── Musiqa aniqlash ─────────────────────────────────────────────────────────

async def find_music(video_path: str) -> dict | None:
    """
    Videodagi qo'shiqni AudD API orqali aniqlaydi.
    Natija: {title, artist, shazam_url, yt_query}

    yt_query endi "Artist - Title audio" formatida (ytsearch1: prefikssiz),
    chunki download_mp3() Invidious search orqali o'zi qidiradi.
    """
    audio_path = video_path.rsplit(".", 1)[0] + "_aud.mp3"

    # Faqat 20 soniya — tezroq tahlil, AudD uchun yetarli
    cmd = (
        f'ffmpeg -i "{video_path}" -vn -t 20 '
        f'-ar 44100 -ac 1 -b:a 128k '
        f'"{audio_path}" -y -loglevel quiet'
    )
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    await proc.communicate()

    if not os.path.exists(audio_path):
        return None

    try:
        async with aiohttp.ClientSession() as session:
            with open(audio_path, "rb") as f:
                form = aiohttp.FormData()
                form.add_field("file", f, filename="audio.mp3", content_type="audio/mpeg")
                async with session.post(
                    "https://api.audd.io/",
                    data=form,
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as resp:
                    result = await resp.json()

        if result.get("status") == "success" and result.get("result"):
            track  = result["result"]
            title  = track.get("title", "Noma'lum")
            artist = track.get("artist", "Noma'lum")
            return {
                "title":      title,
                "artist":     artist,
                "shazam_url": track.get("song_link", ""),
                # Faqat qidiruv matni saqlanadi — ytsearch1: prefikssiz.
                # download_mp3() Invidious orqali qidiradi.
                "yt_query":   f"{artist} - {title} audio",
            }
        return None

    except Exception as e:
        print(f"[music] AudD xato: {e}")
        return None
    finally:
        if os.path.exists(audio_path):
            try: os.remove(audio_path)
            except: pass


# ─── MP3 yuklab olish ─────────────────────────────────────────────────────────

async def download_mp3(search_query: str, output_dir: str) -> str | None:
    """
    Qo'shiqni MP3 formatda yuklab oladi.

    Jarayon:
    1. Invidious API orqali video ID topiladi (YouTube serverlarisiz)
    2. invidious:VIDEO_ID formatida yt-dlp ga beriladi
    3. yt-dlp-invidious plugin orqali audio yuklanadi
    4. FFmpeg MP3 ga konvertatsiya qiladi

    Eski "ytsearch1:" prefiksini ham qo'llab-quvvatlaydi (database dagi
    eski yozuvlar uchun).
    """
    # Eski ytsearch1: formatini ham qabul qilamiz — faqat qidirish matnini ajratamiz
    clean_query = search_query.removeprefix("ytsearch1:").strip()

    # Birinchi Invidious orqali video ID topishga harakat qilamiz
    inv_url = await _invidious_search(clean_query)

    if inv_url:
        url_to_use = inv_url
    else:
        # Fallback: yt-dlp ning o'z YouTube qidiruvini ishlatamiz
        # (Invidious barcha instancelari ishlamagan bo'lsa)
        url_to_use = f"ytsearch1:{clean_query}"
        print(f"[music] Fallback: ytsearch ishlatiladi: {url_to_use}")

    file_id = uuid.uuid4().hex[:10]
    output_template = os.path.join(output_dir, f"{file_id}.%(ext)s")

    opts = {
        "format": "bestaudio/best",
        "outtmpl": output_template,
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        # extractor_args (player_client: ios) olib tashlandi —
        # invidious format bilan YouTube extractor chaqirilmaydi
        "postprocessors": [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": "192",
        }],
    }

    # asyncio.get_event_loop() deprecated — get_running_loop() ishlatiladi
    loop = asyncio.get_running_loop()

    def _dl():
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([url_to_use])

    try:
        await loop.run_in_executor(None, _dl)
    except Exception as e:
        print(f"[music] MP3 xato: {e}")
        return None

    for fname in os.listdir(output_dir):
        if fname.startswith(file_id) and fname.endswith(".mp3"):
            return os.path.join(output_dir, fname)
    return None
